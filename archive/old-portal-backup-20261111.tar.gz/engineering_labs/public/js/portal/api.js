// Client for the engineering_labs.api endpoints. Reads are GET requests; changes are POST requests
// carrying the CSRF token Frappe injects into the page (frappe.csrf_token).
const BASE_URL = "/api/method/engineering_labs.api.";

export async function call(method, args = {}, { post = false } = {}) {
	const params = Object.fromEntries(
		Object.entries(args).filter(([, value]) => value !== undefined && value !== null && value !== "")
	);
	let url = BASE_URL + method;
	const options = { credentials: "same-origin", headers: { Accept: "application/json" } };

	if (post) {
		options.method = "POST";
		options.headers["Content-Type"] = "application/json";
		options.headers["X-Frappe-CSRF-Token"] = window.frappe?.csrf_token || "";
		options.body = JSON.stringify(params);
	} else if (Object.keys(params).length) {
		url += `?${new URLSearchParams(params)}`;
	}

	const response = await fetch(url, options);
	const data = await response.json().catch(() => ({}));
	if (!response.ok) throw new Error(serverMessage(data) || `Request failed (${response.status})`);
	return data.message;
}

// Frappe returns user-facing errors as a JSON list of JSON-encoded messages in _server_messages.
function serverMessage(data) {
	try {
		const messages = JSON.parse(data._server_messages || "[]").map((m) => JSON.parse(m).message);
		if (messages.length) return messages.join(" ").replace(/<[^>]+>/g, "");
	} catch {
		// Fall through to the exception text.
	}
	return data.exception?.split(":").slice(1).join(":").trim();
}

export function showError(error) {
	console.error(error);
	const message = error?.message || "Something went wrong.";
	if (window.frappe?.msgprint) window.frappe.msgprint(message);
	else window.alert(message);
}
