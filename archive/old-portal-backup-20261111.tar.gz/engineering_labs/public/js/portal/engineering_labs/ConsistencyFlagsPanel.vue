<template>
	<Panel title="Consistency flags (parameter lineage)">
		<div
			v-for="flag in flags"
			:key="flag.reference"
			class="tw-mb-2 tw-rounded-[5px] tw-border tw-border-solid tw-border-[#f3c77a] tw-bg-[#fff8e6] tw-px-[10px] tw-py-[9px] tw-text-[11px]"
		>
			<div class="tw-mb-[3px] tw-font-bold tw-text-[#9a4a06]">{{ flag.reference }}</div>
			<div class="tw-text-[#a85a12]">⚠ {{ flag.message }}</div>
		</div>
		<p class="tw-m-0 tw-mt-[10px] tw-text-[10px] tw-text-portal-muted">{{ note }}</p>
	</Panel>
</template>

<script setup>
import Panel from "./Panel.vue";

defineProps({
	flags: { type: Array, required: true },
	note: { type: String, default: "" },
});
</script>
