<template>
	<Panel title="Tool popularity (last 30 days)">
		<ProgressBar
			v-for="tool in tools"
			:key="tool.label"
			:label="tool.label"
			:value="tool.count"
			:max="maxCount"
			:value-text="String(tool.count)"
		/>
	</Panel>
</template>

<script setup>
import { computed } from "vue";
import Panel from "./Panel.vue";
import ProgressBar from "./ProgressBar.vue";

const props = defineProps({
	tools: { type: Array, required: true },
});

const maxCount = computed(() => Math.max(...props.tools.map((tool) => tool.count)));
</script>
