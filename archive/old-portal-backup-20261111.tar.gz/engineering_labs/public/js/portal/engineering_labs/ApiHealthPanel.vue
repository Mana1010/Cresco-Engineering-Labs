<template>
	<Panel title="External API health (24h)">
		<ul class="tw-m-0 tw-list-none tw-p-0">
			<li
				v-for="api in apis"
				:key="api.label"
				class="tw-flex tw-items-center tw-gap-2 tw-py-[6px] tw-text-[11px] tw-text-portal-text"
			>
				<span class="tw-h-[8px] tw-w-[8px] tw-shrink-0 tw-rounded-[50%]" :class="DOT_CLASSES[api.status] || ''"></span>
				<span>{{ api.label }}</span>
				<span class="tw-ml-auto tw-whitespace-nowrap tw-font-mono tw-text-portal-muted">{{ api.latency }} · {{ api.errors }} err</span>
			</li>
		</ul>
	</Panel>
</template>

<script setup>
import Panel from "./Panel.vue";

defineProps({
	apis: { type: Array, required: true },
});

// Full class strings (not built dynamically) so Tailwind can find them when scanning the source.
const DOT_CLASSES = {
	ok: "tw-bg-portal-green",
	degraded: "tw-bg-portal-orange",
	down: "tw-bg-portal-red",
};
</script>
