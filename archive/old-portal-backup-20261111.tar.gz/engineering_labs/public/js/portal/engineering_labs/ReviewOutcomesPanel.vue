<template>
	<Panel title="Review outcomes (30 days)">
		<div class="tw-mb-[14px] tw-flex tw-flex-wrap tw-items-baseline tw-gap-x-[16px] tw-gap-y-[6px] tw-text-[22px] tw-font-bold">
			<span class="tw-text-portal-green">{{ passed }} pass</span>
			<span class="tw-text-portal-red">{{ returned }} returned</span>
			<span class="tw-text-[11px] tw-font-normal tw-text-portal-muted">of {{ reviewed }} reviewed</span>
		</div>

		<h4 class="tw-m-0 tw-mb-[10px] tw-text-[10px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Returns by reason</h4>
		<ProgressBar
			v-for="reason in returnReasons"
			:key="reason.label"
			:label="reason.label"
			:value="reason.count"
			:max="maxReturns"
			:value-text="String(reason.count)"
			:tone="reason.tone"
		/>

		<h4 class="tw-m-0 tw-mb-[10px] tw-text-[10px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate tw-mt-[18px]">
			Top corrected fields (data-entry returns · from payload diffs)
		</h4>
		<ul class="tw-m-0 tw-list-none tw-p-0">
			<li
				v-for="field in correctedFields"
				:key="field.label"
				class="tw-flex tw-justify-between tw-border-0 tw-border-t tw-border-solid tw-border-t-[#e8ecf0] tw-py-[7px] tw-text-[12px] tw-text-portal-text"
			>
				<span>{{ field.label }}</span>
				<strong>{{ field.count }}</strong>
			</li>
		</ul>

		<p class="tw-m-0 tw-mt-[14px] tw-text-[10px] tw-italic tw-text-portal-muted">{{ note }}</p>
	</Panel>
</template>

<script setup>
import { computed } from "vue";
import Panel from "./Panel.vue";
import ProgressBar from "./ProgressBar.vue";

const props = defineProps({
	passed: { type: Number, required: true },
	returned: { type: Number, required: true },
	reviewed: { type: Number, required: true },
	returnReasons: { type: Array, required: true },
	correctedFields: { type: Array, required: true },
	note: { type: String, default: "" },
});

const maxReturns = computed(() => Math.max(...props.returnReasons.map((reason) => reason.count)));
</script>
