<template>
	<Panel title="Timeliness">
		<ul class="tw-m-0 tw-list-none tw-p-0">
			<li
				v-for="row in rows"
				:key="row.label"
				class="tw-flex tw-justify-between tw-gap-[12px] tw-border-0 tw-border-t tw-border-solid tw-border-t-[#e8ecf0] tw-py-[7px] tw-text-[11px] tw-text-portal-text"
			>
				<span class="tw-text-portal-muted">{{ row.label }}</span>
				<strong>{{ row.value }}</strong>
			</li>
		</ul>
	</Panel>
</template>

<script setup>
import Panel from "./Panel.vue";

defineProps({
	rows: { type: Array, required: true },
});
</script>
