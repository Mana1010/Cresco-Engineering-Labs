<template>
	<section class="portal-card tw-px-4 tw-py-[18px]">
		<h3 class="tw-mb-[14px] tw-mt-0 tw-text-[11px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">
			{{ title }}
		</h3>
		<slot />
	</section>
</template>

<script setup>
defineProps({
	title: { type: String, required: true },
});
</script>
