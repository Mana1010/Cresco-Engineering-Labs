<template>
	<div class="el-bar">
		<div class="tw-mb-[5px] tw-flex tw-justify-between tw-gap-[12px] tw-text-[11px]">
			<span class="tw-font-bold tw-text-portal-text">{{ label }}</span>
			<span class="tw-whitespace-nowrap tw-text-portal-muted">{{ valueText }}</span>
		</div>
		<div class="tw-h-[8px] tw-overflow-hidden tw-rounded-[4px] tw-bg-portal-track">
			<div class="tw-h-full tw-rounded-[4px]" :style="{ width: `${percent}%`, background: toneColor(tone) }"></div>
		</div>
		<div v-if="caption" class="tw-mt-[5px] tw-text-[10px] tw-text-portal-muted">{{ caption }}</div>
	</div>
</template>

<script setup>
import { computed } from "vue";
import { toneColor } from "./tones";

const props = defineProps({
	label: { type: String, required: true },
	value: { type: Number, required: true },
	max: { type: Number, required: true },
	valueText: { type: String, default: "" },
	caption: { type: String, default: "" },
	tone: { type: String, default: "primary" },
});

const percent = computed(() => (props.max > 0 ? Math.min(100, (props.value / props.max) * 100) : 0));
</script>

<style scoped>
/* Kept as plain CSS: sibling selector between ProgressBar roots. */
.el-bar + .el-bar {
	margin-top: 12px;
}
</style>
