<template>
	<div class="portal-card tw-px-4 tw-py-[18px]">
		<div
			class="tw-text-[10px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate"
		>
			{{ label }}
		</div>
		<div
			class="tw-mb-1 tw-mt-[6px] tw-text-[26px] tw-font-bold tw-leading-[1.1]"
			:style="{ color: toneColor(tone) }"
		>
			{{ value }}
		</div>
		<div class="tw-text-[11px] tw-text-portal-muted">{{ caption }}</div>
	</div>
</template>

<script setup>
import { toneColor } from "./tones";

defineProps({
	label: { type: String, required: true },
	value: { type: String, required: true },
	caption: { type: String, default: "" },
	tone: { type: String, default: "" },
});
</script>
