// Maps semantic tone names used in demo data to the portal colour tokens.
export const toneColor = (tone) => (tone ? `var(--portal-${tone})` : "var(--portal-text)");
