<template>
	<Panel title="External API quota">
		<ProgressBar
			v-for="quota in quotas"
			:key="quota.label"
			:label="quota.label"
			:value="quota.used"
			:max="quota.limit"
			:value-text="`${quota.used} / ${quota.limit} ${quota.unit}`"
			:caption="quota.renews"
			:tone="quota.tone"
		/>
	</Panel>
</template>

<script setup>
import Panel from "./Panel.vue";
import ProgressBar from "./ProgressBar.vue";

defineProps({
	quotas: { type: Array, required: true },
});
</script>
