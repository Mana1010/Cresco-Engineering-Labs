<template>
	<header
		class="tw-sticky tw-top-0 tw-z-10 tw-flex tw-h-[84px] tw-items-center tw-gap-[22px] tw-bg-[#fff] tw-py-0 tw-pl-[22px] tw-pr-6 tw-shadow-[0_1px_3px_rgba(0,0,0,0.06)] max-640:tw-gap-3 max-640:tw-pl-4 max-640:tw-pr-4"
	>
		<button
			type="button"
			class="tw-box-border tw-flex tw-h-[42px] tw-w-[42px] tw-shrink-0 tw-cursor-pointer tw-items-center tw-justify-center tw-rounded-[6px] tw-border tw-border-solid tw-border-[#d5d5d5] tw-bg-[#fff] tw-p-[11px] tw-text-[#9a9a9a] [transition:background_0.15s_ease,color_0.15s_ease,border-color_0.15s_ease] hover:tw-border-portal-primary hover:tw-bg-[#eef7fc] hover:tw-text-portal-primary [&_svg]:tw-block [&_svg]:tw-h-full [&_svg]:tw-w-full"
			:aria-label="collapsed ? 'Expand sidebar' : 'Collapse sidebar'"
			:aria-expanded="!collapsed"
			@click="toggle"
			v-html="icons.menu"
		></button>
		<h1 class="tw-m-0 tw-text-[19px] tw-font-bold tw-text-[#111] max-640:tw-text-[16px]">Welcome back, {{ user.first_name }}</h1>

		<div class="tw-ml-auto tw-flex tw-items-center tw-gap-3">
			<span class="tw-relative tw-mr-[10px] tw-h-[18px] tw-w-[18px] tw-text-[#c4c4c4]">
				<span
					class="tw-block tw-h-full tw-w-full [&_svg]:tw-block [&_svg]:tw-h-full [&_svg]:tw-w-full"
					v-html="icons.bell"
				></span>
				<span
					class="tw-absolute tw-right-[-1px] tw-top-[-1px] tw-h-[6px] tw-w-[6px] tw-rounded-[50%] tw-bg-[#e53935]"
				></span>
			</span>
			<Avatar :name="user.full_name || ''" :src="user.user_image" :size="38" />
			<span class="tw-text-[15px] tw-text-[#222] max-640:tw-hidden">{{ user.first_name }}</span>
			<span
				class="tw-h-[14px] tw-w-[14px] tw-text-[#b0b0b0] max-640:tw-hidden [&_svg]:tw-block [&_svg]:tw-h-full [&_svg]:tw-w-full"
				v-html="icons.chevron"
			></span>
		</div>
	</header>
</template>

<script setup>
import Avatar from "./Avatar.vue";
import { icons } from "./icons";
import { useSidebar } from "./useSidebar";

defineProps({
	user: { type: Object, required: true },
});

const { collapsed, toggle } = useSidebar();
</script>

