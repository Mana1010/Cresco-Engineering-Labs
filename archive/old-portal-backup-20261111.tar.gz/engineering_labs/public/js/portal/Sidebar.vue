<template>
	<aside
		ref="sidebar"
		class="portal-sidebar tw-sticky tw-top-0 tw-flex tw-h-screen tw-w-[238px] tw-shrink-0 tw-flex-col tw-overflow-x-hidden tw-bg-[#231f20] tw-text-[#fff] [transition:width_0.2s_ease] max-768:tw-static max-768:tw-h-auto max-768:tw-w-full max-768:tw-pb-3"
		:class="{ 'portal-sidebar--collapsed': collapsed }"
	>
		<div class="portal-sidebar__brand tw-px-4 tw-pb-0 tw-pt-10 tw-text-center max-768:tw-pt-5">
			<img
				v-if="logoSrc"
				:src="logoSrc"
				alt="Cresco Australia"
				class="portal-sidebar__logo-img tw-mx-auto tw-my-0 tw-block tw-max-h-12 tw-max-w-full"
			/>
			<div
				v-else
				class="tw-whitespace-nowrap tw-text-[20px] tw-font-semibold tw-tracking-[1px] tw-text-[#fff]"
				:title="collapsed ? 'Cresco Australia' : null"
			>
				{{ collapsed ? "C" : "Cresco Australia" }}
			</div>
		</div>
		<div class="portal-sidebar__divider tw-mx-4 tw-mb-6 tw-mt-[22px] tw-h-[3px] tw-bg-[#00a0e3]"></div>

		<nav class="portal-sidebar__nav tw-flex tw-flex-col tw-gap-1 tw-overflow-y-auto tw-px-4 tw-py-0">
			<!-- Items with a `to` route are links; the rest are static and non-clickable -->
			<component
				:is="item.to ? RouterLink : 'div'"
				v-for="item in menuItems"
				:key="item.label"
				:to="item.to"
				class="portal-sidebar__item tw-box-border tw-flex tw-w-full tw-cursor-default tw-select-none tw-items-center tw-gap-[10px] tw-whitespace-nowrap tw-rounded-[6px] tw-border-0 tw-bg-transparent tw-px-[14px] tw-py-2 tw-text-left tw-text-[11px] tw-font-bold tw-text-[#fff] [font-family:inherit] [font-stretch:inherit] [font-style:inherit] [font-variant:inherit] [line-height:inherit]"
				:class="{
					'portal-sidebar__item--active': item.routeName === route.name,
					'portal-sidebar__item--clickable': item.to,
				}"
				:aria-disabled="item.to ? null : 'true'"
				:aria-label="collapsed ? item.label : null"
				:title="collapsed ? item.label : null"
			>
				<span class="portal-sidebar__icon tw-inline-flex tw-h-[15px] tw-w-[15px] tw-shrink-0 [&_svg]:tw-h-full [&_svg]:tw-w-full" v-html="item.icon"></span>
				<span class="portal-sidebar__label portal-sidebar__text" :data-text="item.label">{{ item.label }}</span>
			</component>

			<!-- Engineering Labs dropdown -->
			<div>
				<button
					ref="labsButton"
					type="button"
					class="portal-sidebar__item tw-box-border tw-flex tw-w-full tw-cursor-default tw-select-none tw-items-center tw-gap-[10px] tw-whitespace-nowrap tw-rounded-[6px] tw-border-0 tw-bg-transparent tw-px-[14px] tw-py-2 tw-text-left tw-text-[11px] tw-font-bold tw-text-[#fff] [font-family:inherit] [font-stretch:inherit] [font-style:inherit] [font-variant:inherit] [line-height:inherit] portal-sidebar__item--clickable"
					:class="{ 'portal-sidebar__item--active': collapsed && (inEngineeringLabs || flyoutOpen) }"
					:aria-expanded="collapsed ? flyoutOpen : isOpen"
					:aria-haspopup="collapsed ? 'menu' : null"
					:aria-label="collapsed ? 'Engineering Labs' : null"
					@click="onEngineeringLabsClick"
					@mouseenter="collapsed && openFlyout()"
					@mouseleave="collapsed && scheduleFlyoutClose()"
				>
					<span class="portal-sidebar__icon tw-inline-flex tw-h-[15px] tw-w-[15px] tw-shrink-0 [&_svg]:tw-h-full [&_svg]:tw-w-full" v-html="icons.flask"></span>
					<span class="portal-sidebar__label portal-sidebar__text" data-text="Engineering Labs">
						Engineering Labs
					</span>
					<span
						class="portal-sidebar__chevron tw-ml-auto tw-inline-flex tw-h-3 tw-w-3 [transition:transform_0.15s_ease] [&_svg]:tw-h-full [&_svg]:tw-w-full"
						:class="{ 'tw-rotate-180': isOpen }"
						v-html="icons.chevron"
					></span>
				</button>

				<div v-show="isOpen && !collapsed" class="tw-flex tw-flex-col tw-gap-1 tw-py-1 tw-pl-[29px] tw-pr-0">
					<RouterLink
						v-for="sub in engineeringLabsItems"
						:key="sub.to"
						:to="sub.to"
						class="portal-sidebar__subitem"
						active-class="portal-sidebar__subitem--active"
					>
						<span class="portal-sidebar__text" :data-text="sub.label">{{ sub.label }}</span>
					</RouterLink>
				</div>
			</div>
		</nav>

		<!-- Collapsed-only pop-out for the Engineering Labs submenu. Teleported to <body> so the
		     sidebar's overflow clipping can't cut it off. -->
		<Teleport to="body">
			<div
				v-if="collapsed && flyoutOpen"
				ref="flyout"
				class="portal-flyout tw-fixed tw-z-[1000] tw-box-border tw-flex tw-w-[210px] tw-flex-col tw-gap-1 tw-rounded-[8px] tw-bg-[#231f20] tw-p-2 tw-font-portal tw-shadow-[0_8px_24px_rgba(0,0,0,0.25)]"
				role="menu"
				aria-label="Engineering Labs"
				:style="{ top: `${flyoutPosition.top}px`, left: `${flyoutPosition.left}px` }"
				@mouseenter="cancelFlyoutClose"
				@mouseleave="scheduleFlyoutClose"
			>
				<div
					class="tw-mb-1 tw-border-0 tw-border-b tw-border-solid tw-border-b-[rgba(255,255,255,0.12)] tw-px-[10px] tw-pb-2 tw-pt-1 tw-text-[11px] tw-font-bold tw-text-[#fff]"
				>
					Engineering Labs
				</div>
				<RouterLink
					v-for="sub in engineeringLabsItems"
					:key="sub.to"
					:to="sub.to"
					role="menuitem"
					class="portal-flyout__item"
					active-class="portal-flyout__item--active"
					@click="closeFlyout"
				>
					<span class="portal-sidebar__text" :data-text="sub.label">{{ sub.label }}</span>
				</RouterLink>
			</div>
		</Teleport>

		<div class="tw-mt-auto tw-h-9 tw-shrink-0 tw-bg-[#00a0e3] max-768:tw-hidden"></div>
	</aside>
</template>

<script setup>
import { computed, nextTick, onBeforeUnmount, onMounted, reactive, ref, watch } from "vue";
import { RouterLink, useRoute, useRouter } from "vue-router";
import { icons } from "./icons";
import { useSidebar } from "./useSidebar";

// Set to the logo image URL once available; falls back to a text placeholder while null.
const logoSrc = null;

const route = useRoute();
const router = useRouter();
const { collapsed } = useSidebar();

const inEngineeringLabs = computed(() => route.path.startsWith("/engineering-labs"));

// Start expanded when landing directly on an Engineering Labs page so the active submenu is visible.
const isOpen = ref(window.location.pathname.startsWith("/engineering-labs"));

const menuItems = [
	{ label: "Dashboard", icon: icons.dashboard, routeName: "dashboard", to: "/portal" },
	{ label: "Projects", icon: icons.folder },
	{ label: "Proposals", icon: icons.document },
	{ label: "Deliverables", icon: icons.check },
	{ label: "Inspections", icon: icons.clipboard },
	{ label: "Analytics", icon: icons.analytics },
	{ label: "Desk", icon: icons.chat },
];

// Submenu items have no icons, so when collapsed they're shown in a pop-out next to the icon
// instead: hovering opens it, clicking pins it open until a link, Escape, or a click elsewhere.
const FLYOUT_WIDTH = 210;
const FLYOUT_CLOSE_DELAY_MS = 150;

const sidebar = ref(null);
const labsButton = ref(null);
const flyout = ref(null);
const flyoutOpen = ref(false);
const flyoutPinned = ref(false);
const flyoutPosition = reactive({ top: 0, left: 0 });
let closeTimer = null;

function positionFlyout() {
	const rect = labsButton.value.getBoundingClientRect();
	const sidebarRight = sidebar.value.getBoundingClientRect().right;
	const fitsBeside = sidebarRight + 8 + FLYOUT_WIDTH <= window.innerWidth;
	// Just outside the sidebar's edge normally; below the icon when the sidebar is a top icon row
	// on narrow screens.
	flyoutPosition.top = fitsBeside ? rect.top : rect.bottom + 6;
	flyoutPosition.left = fitsBeside
		? sidebarRight + 8
		: Math.max(8, Math.min(rect.left, window.innerWidth - FLYOUT_WIDTH - 8));
}

function openFlyout() {
	cancelFlyoutClose();
	positionFlyout();
	flyoutOpen.value = true;
}

function closeFlyout() {
	cancelFlyoutClose();
	flyoutOpen.value = false;
	flyoutPinned.value = false;
}

function scheduleFlyoutClose() {
	if (flyoutPinned.value) return;
	cancelFlyoutClose();
	closeTimer = setTimeout(closeFlyout, FLYOUT_CLOSE_DELAY_MS);
}

function cancelFlyoutClose() {
	clearTimeout(closeTimer);
}

const ENGINEERING_LABS_HOME = "/engineering-labs/home";

function onEngineeringLabsClick() {
	// Coming from outside Engineering Labs, the button lands on its Home page. Once inside, it only
	// toggles the submenu / pop-out so it doesn't pull the user away from the page they're on.
	if (!inEngineeringLabs.value) {
		isOpen.value = true;
		closeFlyout();
		router.push(ENGINEERING_LABS_HOME);
		return;
	}
	if (!collapsed.value) {
		isOpen.value = !isOpen.value;
		return;
	}
	if (flyoutPinned.value) {
		closeFlyout();
	} else {
		openFlyout();
		flyoutPinned.value = true;
		nextTick(() => flyout.value?.querySelector("a")?.focus({ preventScroll: true }));
	}
}

function onDocumentPointerDown(event) {
	if (!flyoutOpen.value) return;
	if (labsButton.value?.contains(event.target) || flyout.value?.contains(event.target)) return;
	closeFlyout();
}

function onDocumentKeydown(event) {
	if (event.key === "Escape" && flyoutOpen.value) {
		closeFlyout();
		labsButton.value?.focus();
	}
}

onMounted(() => {
	document.addEventListener("pointerdown", onDocumentPointerDown);
	document.addEventListener("keydown", onDocumentKeydown);
	window.addEventListener("resize", closeFlyout);
});

onBeforeUnmount(() => {
	document.removeEventListener("pointerdown", onDocumentPointerDown);
	document.removeEventListener("keydown", onDocumentKeydown);
	window.removeEventListener("resize", closeFlyout);
	cancelFlyoutClose();
});

watch(collapsed, (isCollapsed) => {
	if (!isCollapsed) closeFlyout();
});
watch(() => route.fullPath, closeFlyout);

const engineeringLabsItems = [
	{ label: "Home", to: "/engineering-labs/home" },
	{ label: "Calculation Catalogue", to: "/engineering-labs/calculation-catalogue" },
	{ label: "Tools Registry", to: "/engineering-labs/tools-registry" },
];
</script>

<style scoped>
/* Kept as plain CSS (hybrid Tailwind conversion): multi-state selectors, collapsed-mode descendant
   rules, the bold-width ::after trick, scrollbar styling and the keyframe animation. Everything
   else is Tailwind utilities in the template. */
.portal-sidebar__nav {
	/* On short screens the menu scrolls; keep the scrollbar's space reserved (and the bar thin and
	   dark) so it appearing when the submenu opens doesn't narrow the items. */
	scrollbar-gutter: stable both-edges;
	scrollbar-width: thin;
	scrollbar-color: rgba(255, 255, 255, 0.25) transparent;
}

/* Active, hover and normal states only change colours and font weight; size comes from padding and
   the parent's gap, so selecting an item never moves the others. */
.portal-sidebar__item--active,
.portal-sidebar__item--active:hover {
	background: #00a0e3;
}

.portal-sidebar__item--clickable {
	cursor: pointer;
	text-decoration: none;
}

a.portal-sidebar__item,
a.portal-sidebar__item:hover {
	color: #fff;
	text-decoration: none;
}

.portal-sidebar__item--clickable:not(.portal-sidebar__item--active):hover {
	background: rgba(255, 255, 255, 0.08);
}

.portal-sidebar__subitem {
	display: flex;
	white-space: nowrap;
	padding: 6px 10px;
	border-radius: 5px;
	font-size: 11px;
	color: rgba(255, 255, 255, 0.8);
	text-decoration: none;
	user-select: none;
}

.portal-sidebar__subitem:hover {
	color: #fff;
	background: rgba(255, 255, 255, 0.08);
	text-decoration: none;
}

.portal-sidebar__subitem--active,
.portal-sidebar__subitem--active:hover {
	background: #00a0e3;
	color: #fff;
	font-weight: 700;
}

/* Reserves the width of the bold version of each label (an invisible bold copy via data-text), so
   switching to bold when active doesn't change the item's size. */
.portal-sidebar__text {
	display: inline-flex;
	flex-direction: column;
}

.portal-sidebar__text::after {
	content: attr(data-text);
	height: 0;
	overflow: hidden;
	visibility: hidden;
	font-weight: 700;
	pointer-events: none;
	user-select: none;
}

/* Collapsed: icons only */
.portal-sidebar--collapsed {
	width: 72px;
}

.portal-sidebar--collapsed .portal-sidebar__brand {
	padding-left: 8px;
	padding-right: 8px;
}

.portal-sidebar--collapsed .portal-sidebar__logo-img {
	max-height: 32px;
}

.portal-sidebar--collapsed .portal-sidebar__divider {
	margin-left: 12px;
	margin-right: 12px;
}

.portal-sidebar--collapsed .portal-sidebar__nav {
	padding: 0 12px;
}

.portal-sidebar--collapsed .portal-sidebar__item {
	justify-content: center;
	width: 100%;
	padding: 10px 0;
}

.portal-sidebar--collapsed .portal-sidebar__label,
.portal-sidebar--collapsed .portal-sidebar__chevron {
	display: none;
}

.portal-sidebar--collapsed .portal-sidebar__icon {
	width: 17px;
	height: 17px;
}

@media (max-width: 768px) {
	/* On narrow screens the sidebar sits above the content, so collapsed becomes a row of icons. */
	.portal-sidebar--collapsed {
		width: 100%;
	}

	.portal-sidebar--collapsed .portal-sidebar__nav {
		flex-direction: row;
		flex-wrap: wrap;
		justify-content: center;
	}

	.portal-sidebar--collapsed .portal-sidebar__item {
		width: 44px;
	}
}

.portal-flyout {
	animation: portal-flyout-in 0.12s ease-out;
}

.portal-flyout__item {
	display: flex;
	padding: 7px 10px;
	border-radius: 5px;
	font-size: 11px;
	color: rgba(255, 255, 255, 0.8);
	text-decoration: none;
	white-space: nowrap;
}

.portal-flyout__item:hover,
.portal-flyout__item:focus-visible {
	background: rgba(255, 255, 255, 0.08);
	color: #fff;
	text-decoration: none;
	outline: none;
}

.portal-flyout__item--active,
.portal-flyout__item--active:hover {
	background: #00a0e3;
	color: #fff;
	font-weight: 700;
}

@keyframes portal-flyout-in {
	from {
		opacity: 0;
		transform: translateX(-4px);
	}
}
</style>
