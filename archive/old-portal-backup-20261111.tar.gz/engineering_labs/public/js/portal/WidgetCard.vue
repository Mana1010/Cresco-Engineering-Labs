<template>
	<section class="portal-card tw-flex tw-flex-col tw-overflow-hidden">
		<header class="tw-flex tw-items-center tw-gap-[6px] tw-pb-0 tw-pl-[18px] tw-pr-4 tw-pt-3">
			<span class="widget__icon tw-text-[#1a9fd9]" v-html="icons[icon]"></span>
			<h3 class="tw-m-0 tw-text-[13px] tw-font-bold tw-text-[#222]">{{ title }}</h3>
			<span v-if="actionLabel" class="tw-ml-auto tw-cursor-default tw-text-[10px] tw-text-[#1a9fd9]">{{ actionLabel }}</span>
		</header>
		<div class="tw-pb-3 tw-pl-[18px] tw-pr-4 tw-pt-[6px]">
			<slot />
		</div>
		<footer v-if="footerLabel" class="tw-mt-auto tw-flex tw-cursor-default tw-items-center tw-justify-between tw-bg-[#e3f2fa] tw-py-[6px] tw-pl-[18px] tw-pr-4 tw-text-[10px] tw-text-[#1a9fd9]">
			<span>{{ footerLabel }}</span>
			<span class="widget__footer-icon" v-html="icons.arrowRight"></span>
		</footer>
	</section>
</template>

<script setup>
import { icons } from "./icons";

defineProps({
	title: { type: String, required: true },
	icon: { type: String, required: true },
	actionLabel: { type: String, default: "" },
	footerLabel: { type: String, default: "" },
});
</script>

<style scoped>
.widget__icon,
.widget__icon :deep(svg),
.widget__footer-icon,
.widget__footer-icon :deep(svg) {
	display: block;
	width: 17px;
	height: 17px;
}

.widget__footer-icon,
.widget__footer-icon :deep(svg) {
	width: 11px;
	height: 11px;
}
</style>
