<template>
	<WidgetCard title="Upcoming Events" icon="calendar" action-label="View Calendar" footer-label="See all events">
		<p v-if="!events.length" class="tw-mx-0 tw-mb-[2px] tw-mt-[6px] tw-text-[10px] tw-text-[#999]">No upcoming events.</p>
		<ul v-else class="tw-m-0 tw-mt-1 tw-list-none tw-p-0">
			<li v-for="event in events" :key="event.title" class="tw-flex tw-items-center tw-gap-[10px] tw-px-0 tw-py-1">
				<span class="tw-box-border tw-flex tw-h-[32px] tw-w-[30px] tw-flex-shrink-0 tw-flex-col tw-items-center tw-overflow-hidden tw-rounded-[4px] tw-border tw-border-solid tw-border-[#555]">
					<span class="tw-w-full tw-bg-[#1a9fd9] tw-text-center tw-text-[4px] tw-leading-[6px] tw-text-white">{{ event.month }}</span>
					<span class="tw-text-[17px] tw-font-bold tw-leading-[24px] tw-text-[#222]">{{ event.day }}</span>
				</span>
				<div>
					<div class="tw-text-[11px] tw-font-bold tw-text-[#222]">
						{{ event.title }}
						<span class="tw-ml-[6px] tw-text-[9px] tw-font-normal tw-text-[#999]">{{ event.time }}</span>
					</div>
					<div class="tw-text-[8px] tw-text-[#999]">{{ event.location }}</div>
				</div>
			</li>
		</ul>
	</WidgetCard>
</template>

<script setup>
import WidgetCard from "./WidgetCard.vue";

defineProps({
	events: { type: Array, required: true },
});
</script>

