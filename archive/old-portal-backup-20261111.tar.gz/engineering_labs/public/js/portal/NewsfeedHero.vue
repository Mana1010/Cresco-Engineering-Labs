<template>
	<section
		class="newsfeed tw-relative tw-flex tw-min-h-[454px] tw-overflow-hidden tw-rounded-[6px] tw-bg-[#5a7e94] tw-bg-cover tw-bg-center tw-shadow-[0_1px_4px_rgba(0,0,0,0.12)] max-640:tw-min-h-[360px]"
		:class="{ 'newsfeed--placeholder': !imageSrc }"
		:style="imageSrc ? { backgroundImage: `url(${imageSrc})` } : null"
	>
		<div class="tw-relative tw-flex tw-max-w-[360px] tw-flex-col tw-justify-center tw-px-[38px] tw-py-10 tw-text-white max-640:tw-px-[22px] max-640:tw-py-[28px]">
			<h2 class="tw-m-0 tw-text-[50px] tw-font-bold tw-leading-[1.12] tw-text-white max-640:tw-text-[36px]">{{ title }}</h2>
			<div class="tw-mx-0 tw-mb-[22px] tw-mt-[28px] tw-h-[3px] tw-w-[185px] tw-bg-white"></div>
			<p class="tw-m-0 tw-mb-[54px] tw-max-w-[250px] tw-text-[12px] tw-leading-[1.5]">{{ body }}</p>
			<span class="tw-inline-flex tw-cursor-default tw-items-center tw-gap-[14px] tw-self-start tw-rounded-[6px] tw-bg-[#00a0e3] tw-px-4 tw-py-3 tw-text-[15px] tw-font-medium">
				View Newsfeed
				<span class="newsfeed__button-icon" v-html="icons.arrowRight"></span>
			</span>
		</div>
	</section>
</template>

<script setup>
import { icons } from "./icons";

defineProps({
	imageSrc: { type: String, default: null },
	title: { type: String, required: true },
	body: { type: String, default: "" },
});
</script>

<style scoped>
.newsfeed--placeholder {
	background-image: linear-gradient(135deg, #3d6680 0%, #6f97ae 45%, #aac3d1 100%);
}

.newsfeed::before {
	content: "";
	position: absolute;
	inset: 0;
	background: linear-gradient(90deg, rgba(20, 45, 60, 0.45) 0%, rgba(20, 45, 60, 0) 60%);
}

.newsfeed__button-icon,
.newsfeed__button-icon :deep(svg) {
	display: block;
	width: 15px;
	height: 15px;
}
</style>
