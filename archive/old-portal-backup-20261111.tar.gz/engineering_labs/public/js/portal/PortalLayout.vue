<template>
	<div class="tw-flex tw-min-h-screen max-768:tw-flex-col">
		<Sidebar />
		<div class="tw-flex tw-min-w-0 tw-flex-1 tw-flex-col">
			<PortalHeader :user="user" />
			<main class="tw-pb-[26px] tw-pl-[28px] tw-pr-[26px] tw-pt-[18px] max-640:tw-p-4">
				<RouterView />
			</main>
		</div>
	</div>
</template>

<script setup>
// Page-wide styles (colour variables, html/body, .portal-card) live in public/css/tailwind.css.
import { provide } from "vue";
import PortalHeader from "./PortalHeader.vue";
import Sidebar from "./Sidebar.vue";

const props = defineProps({
	user: { type: Object, required: true },
});

provide("portalUser", props.user);
</script>
