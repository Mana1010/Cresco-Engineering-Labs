<template>
	<div
		class="project-card tw-flex tw-cursor-pointer tw-flex-col tw-rounded-[8px]"
		:class="{ 'project-card--selected': selected }"
		role="radio"
		:aria-checked="selected"
		tabindex="0"
		@click="$emit('select', project)"
		@keydown.enter.prevent="$emit('select', project)"
		@keydown.space.prevent="$emit('select', project)"
	>
		<div class="tw-px-4 tw-pb-3 tw-pt-[14px]">
			<div class="tw-flex tw-justify-between tw-gap-3">
				<div>
					<h3 class="tw-m-0 tw-text-[13px] tw-font-bold tw-text-portal-text">{{ project.name }}</h3>
					<p class="tw-m-0 tw-mt-[2px] tw-text-[11px] tw-text-portal-muted">{{ project.client }} · {{ project.location }}</p>
				</div>
				<span class="project-card__radio tw-box-border tw-h-[16px] tw-w-[16px] tw-flex-shrink-0 tw-rounded-[50%]" aria-hidden="true"></span>
			</div>

			<div class="tw-mt-[10px] tw-flex tw-flex-wrap tw-gap-[6px]">
				<span class="tw-rounded-full tw-border tw-border-solid tw-px-2 tw-py-[2px] tw-text-[10px] tw-font-semibold tw-border-[#d5dbe1] tw-text-portal-slate">{{ project.discipline }}</span>
				<span class="tw-rounded-full tw-border tw-border-solid tw-px-2 tw-py-[2px] tw-text-[10px] tw-font-semibold" :class="stageClass">{{ project.stage }}</span>
			</div>

			<dl class="tw-m-0 tw-mt-3 tw-grid tw-grid-cols-3 tw-gap-2">
				<div>
					<dt class="tw-mb-[2px] tw-text-[9px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Owner</dt>
					<dd class="tw-m-0 tw-text-[11px] tw-text-portal-text">{{ project.owner }}</dd>
				</div>
				<div>
					<dt class="tw-mb-[2px] tw-text-[9px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Calcs</dt>
					<dd class="tw-m-0 tw-text-[11px] tw-text-portal-text">{{ project.calcsDone }}/{{ project.calcsTotal }} done</dd>
				</div>
				<div>
					<dt class="tw-mb-[2px] tw-text-[9px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Portal</dt>
					<dd class="tw-m-0 tw-text-[11px] tw-text-portal-text tw-font-mono">{{ project.portalRef }}</dd>
				</div>
			</dl>
		</div>

		<footer class="tw-mt-auto tw-flex tw-items-center tw-justify-between tw-border-0 tw-border-t tw-border-solid tw-border-t-[#e8ecf0] tw-px-4 tw-py-[10px] tw-text-[10px] tw-text-portal-muted">
			<span class="tw-font-mono">{{ project.id }}</span>
			<!-- Static for now: project details page doesn't exist yet -->
			<span class="tw-inline-flex tw-items-center tw-gap-1 tw-text-[11px] tw-font-semibold tw-text-[#0b7fb3]">
				More details
				<span class="project-card__more-icon" v-html="icons.arrowRight"></span>
			</span>
		</footer>
	</div>
</template>

<script setup>
import { computed } from "vue";
import { icons } from "../icons";

const props = defineProps({
	project: { type: Object, required: true },
	selected: { type: Boolean, default: false },
});

defineEmits(["select"]);

// Full class strings (not built dynamically) so Tailwind can find them when scanning the source.
const stageClass = computed(() =>
	props.project.stage === "WIP"
		? "tw-border-[#b7dff2] tw-bg-[#e2f2fa] tw-text-[#1676a3]"
		: "tw-border-[#f3d29a] tw-bg-[#fdf3e1] tw-text-[#a86410]"
);
</script>

<style scoped>
/* Card border/background/shadow states (hover, focus-visible, selected) kept as CSS: their
   specificity interplay (selected+hover beats focus-visible) is easier to keep exact here. */
.project-card {
	border: 1px solid #e3e8ed;
	background: #fff;
	transition:
		border-color 0.15s ease,
		box-shadow 0.15s ease,
		background 0.15s ease;
}

.project-card:hover {
	border-color: #9fd6ef;
	box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
}

.project-card:focus-visible {
	outline: none;
	box-shadow: 0 0 0 2px var(--portal-primary);
}

.project-card--selected,
.project-card--selected:hover {
	border-color: var(--portal-primary);
	background: #f0f9fd;
	box-shadow: 0 0 0 1px var(--portal-primary);
}

.project-card__radio {
	border: 1.5px solid #b8c2cc;
}

.project-card--selected .project-card__radio {
	border: 5px solid var(--portal-primary);
}

.project-card__more-icon,
.project-card__more-icon :deep(svg) {
	display: block;
	width: 11px;
	height: 11px;
}
</style>
