// Cresco Project records (engineering_labs.api.get_projects), shaped for the project picker.
import { call } from "../api";

const toProject = (row) => ({
	id: row.name,
	name: row.project_name,
	client: row.client,
	location: row.location,
	address: row.site_address,
	discipline: row.discipline,
	stage: row.stage,
	owner: row.project_owner,
	calcsDone: row.calcs_done,
	calcsTotal: row.calcs_total,
	portalRef: row.portal_ref,
});

export const fetchProjects = async (search = "") => (await call("get_projects", { search })).map(toProject);
