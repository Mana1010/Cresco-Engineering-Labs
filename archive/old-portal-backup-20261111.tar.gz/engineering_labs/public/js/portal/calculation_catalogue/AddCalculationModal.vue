<template>
	<BaseModal size="xl" @close="$emit('close')">
		<template #header="{ titleId }">
			<p class="tw-m-0 tw-mb-1 tw-text-[10px] tw-font-bold tw-uppercase tw-tracking-[0.6px] tw-text-portal-slate">Step {{ step }} of 2</p>

			<template v-if="step === 1">
				<h2 :id="titleId" class="tw-m-0 tw-text-[17px] tw-font-bold tw-text-portal-text">Select a project</h2>
				<p class="tw-m-0 tw-mt-1 tw-text-[12px] tw-text-portal-muted">Choose the project this calculation belongs to.</p>
				<label class="tw-relative tw-mt-[14px] tw-flex tw-items-center">
					<span class="add-calc__search-icon tw-pointer-events-none tw-absolute tw-left-3 tw-h-[14px] tw-w-[14px] tw-text-portal-muted" aria-hidden="true" v-html="icons.search"></span>
					<input
						v-model="search"
						class="add-calc__search-input tw-box-border tw-h-[38px] tw-w-full tw-rounded-[6px] tw-border tw-border-solid tw-border-[#d5dbe1] tw-py-0 tw-pl-[34px] tw-pr-3 tw-text-portal-text focus:tw-border-portal-primary focus:[box-shadow:0_0_0_3px_rgba(0,160,227,0.15)] focus:[outline:none]"
						type="search"
						placeholder="Search by project, client or Portal ref"
						aria-label="Search projects"
					/>
				</label>
			</template>

			<template v-else>
				<button type="button" class="add-calc__back tw-mb-2 tw-inline-flex tw-cursor-pointer tw-items-center tw-gap-[5px] tw-border-0 tw-p-0 [background:none] tw-text-[#0b7fb3] hover:tw-underline" @click="step = 1">
					<span class="add-calc__back-icon tw-block tw-h-[12px] tw-w-[12px] tw-rotate-180" aria-hidden="true" v-html="icons.arrowRight"></span>
					{{ selectedProject.name }}
				</button>
				<div class="tw-flex tw-flex-wrap tw-items-center tw-gap-x-2 tw-gap-y-[6px]">
					<h2 :id="titleId" class="tw-m-0 tw-text-[17px] tw-font-bold tw-text-portal-text">{{ calc.name }}</h2>
					<CalcBadges :type="calc.type" show-icons />
					<span class="tw-rounded-full tw-border tw-border-solid tw-border-[#b9e2c8] tw-bg-[#e3f4e9] tw-px-2 tw-py-[2px] tw-text-[10px] tw-font-semibold tw-text-[#217a43]">{{ calc.status }} {{ calc.version }}</span>
					<span class="tw-rounded-full tw-border tw-border-solid tw-border-[#d5dbe1] tw-px-2 tw-py-[2px] tw-text-[10px] tw-font-semibold tw-text-portal-slate">Rev A</span>
				</div>
				<p class="tw-m-0 tw-mt-1 tw-text-[12px] tw-text-portal-muted">{{ calc.description }}</p>
			</template>
		</template>

		<template v-if="step === 1">
			<p v-if="projectsLoading && !projects.length" class="tw-mx-0 tw-my-6 tw-text-center tw-text-[13px] tw-text-portal-muted">Loading projects…</p>
			<div v-else-if="projects.length" class="tw-grid tw-grid-cols-2 tw-gap-[14px] max-760:tw-grid-cols-1" role="radiogroup" aria-label="Projects">
				<ProjectCard
					v-for="project in projects"
					:key="project.id"
					:project="project"
					:selected="project.id === selectedProject?.id"
					@select="selectedProject = $event"
				/>
			</div>
			<p v-else class="tw-mx-0 tw-my-6 tw-text-center tw-text-[13px] tw-text-portal-muted">No projects match “{{ search }}”.</p>
		</template>

		<CalculationRunner
			v-else
			:key="selectedProject.id"
			:calc="calc"
			:defaults="{ address: selectedProject.address }"
			show-initial-result
			:log-context="`project ${selectedProject.portalRef}`"
		/>

		<template v-if="step === 1" #footer>
			<span class="tw-text-[12px] tw-text-portal-muted">
				Selected: <strong class="tw-text-portal-text">{{ selectedProject ? selectedProject.name : "—" }}</strong>
			</span>
			<div class="tw-ml-auto tw-flex tw-gap-2">
				<button type="button" class="tw-border tw-border-solid tw-border-[#d5dbe1] tw-bg-[#fff] tw-text-portal-text add-calc__btn tw-cursor-pointer tw-rounded-[6px] tw-px-[22px] tw-py-[9px] enabled:hover:[filter:brightness(0.93)] disabled:tw-cursor-default disabled:tw-opacity-50" @click="$emit('close')">Cancel</button>
				<button type="button" class="tw-border-0 tw-bg-portal-primary tw-text-white add-calc__btn tw-cursor-pointer tw-rounded-[6px] tw-px-[22px] tw-py-[9px] enabled:hover:[filter:brightness(0.93)] disabled:tw-cursor-default disabled:tw-opacity-50" :disabled="!selectedProject || !calc" @click="step = 2">
					Continue
				</button>
			</div>
		</template>
	</BaseModal>
</template>

<script setup>
import { onBeforeUnmount, onMounted, ref, watch } from "vue";
import { showError } from "../api";
import BaseModal from "../BaseModal.vue";
import { icons } from "../icons";
import CalcBadges from "../tools_registry/CalcBadges.vue";
import CalculationRunner from "../tools_registry/CalculationRunner.vue";
import { fetchCalculationByName } from "../tools_registry/registryData";
import ProjectCard from "./ProjectCard.vue";
import { fetchProjects } from "./projects";

defineEmits(["close"]);

// The flow is built around CheckWind (mockup 11); choosing which calculation to add isn't specified yet.
const CALCULATION_NAME = "Wind Classification (CheckWind)";
const SEARCH_DEBOUNCE_MS = 250;

const step = ref(1);
const search = ref("");
const selectedProject = ref(null);
const calc = ref(null);
const projects = ref([]);
const projectsLoading = ref(false);
let searchTimer = null;
let latestSearch = 0;

async function loadProjects() {
	const requestId = ++latestSearch;
	projectsLoading.value = true;
	try {
		const result = await fetchProjects(search.value);
		if (requestId === latestSearch) projects.value = result;
	} catch (error) {
		showError(error);
	} finally {
		if (requestId === latestSearch) projectsLoading.value = false;
	}
}

watch(search, () => {
	clearTimeout(searchTimer);
	searchTimer = setTimeout(loadProjects, SEARCH_DEBOUNCE_MS);
});

onMounted(async () => {
	loadProjects();
	try {
		calc.value = await fetchCalculationByName(CALCULATION_NAME);
	} catch (error) {
		showError(error);
	}
});

onBeforeUnmount(() => clearTimeout(searchTimer));
</script>

<style scoped>
.add-calc__search-icon :deep(svg),
.add-calc__back-icon :deep(svg) {
	display: block;
	width: 100%;
	height: 100%;
}

/* `font: inherit` must come before font-size/weight, so these stay together in CSS. */
.add-calc__search-input {
	font: inherit;
	font-size: 13px;
}

.add-calc__back {
	font: inherit;
	font-size: 12px;
	font-weight: 600;
}

.add-calc__btn {
	font: inherit;
	font-size: 13px;
	font-weight: 700;
}
</style>
