// Shared collapsed/expanded state for the portal sidebar, toggled from the header menu button.
import { ref, watch } from "vue";

const STORAGE_KEY = "engineering_labs.portal.sidebar_collapsed";

function readCollapsed() {
	try {
		return localStorage.getItem(STORAGE_KEY) === "1";
	} catch {
		return false;
	}
}

const collapsed = ref(readCollapsed());

watch(collapsed, (value) => {
	try {
		localStorage.setItem(STORAGE_KEY, value ? "1" : "0");
	} catch {
		// Storage unavailable (e.g. private mode); the state just won't persist.
	}
});

export function useSidebar() {
	return {
		collapsed,
		toggle: () => (collapsed.value = !collapsed.value),
		expand: () => (collapsed.value = false),
	};
}
