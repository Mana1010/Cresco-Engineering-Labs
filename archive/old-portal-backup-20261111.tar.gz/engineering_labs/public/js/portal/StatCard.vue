<template>
	<div class="portal-card tw-flex tw-items-center tw-gap-3 tw-px-4 tw-py-[22px]" :class="`stat-card--${tone}`">
		<span class="tw-flex tw-h-14 tw-w-14 tw-flex-shrink-0 tw-items-center tw-justify-center tw-rounded-[50%] stat-card__icon"
			><span v-html="icons[icon]"></span
		></span>
		<div>
			<div class="tw-text-[30px] tw-font-bold tw-leading-none stat-card__value">{{ value }}</div>
			<div class="tw-mt-1 tw-text-[12px] tw-font-bold tw-text-[#222]">{{ label }}</div>
			<div class="tw-text-[9px] tw-text-[#444]">{{ sublabel }}</div>
		</div>
	</div>
</template>

<script setup>
import { icons } from "./icons";

defineProps({
	value: { type: Number, required: true },
	label: { type: String, required: true },
	sublabel: { type: String, default: "" },
	icon: { type: String, required: true },
	tone: { type: String, default: "blue" },
});
</script>

<style scoped>
/* Tone system (CSS custom properties per tone modifier) kept as CSS. */
.stat-card__icon {
	background: var(--tone-bg);
	color: var(--tone-fg);
}

.stat-card__icon span,
.stat-card__icon :deep(svg) {
	display: block;
	width: 30px;
	height: 30px;
}

.stat-card__value {
	color: var(--tone-fg);
}

.stat-card--orange {
	--tone-fg: #d2541d;
	--tone-bg: #fbe8de;
}

.stat-card--yellow {
	--tone-fg: #f4b23e;
	--tone-bg: #fef5e2;
}

.stat-card--green {
	--tone-fg: #64bb66;
	--tone-bg: #eaf6e9;
}

.stat-card--blue {
	--tone-fg: #1a9fd9;
	--tone-bg: #e2f2fa;
}
</style>
