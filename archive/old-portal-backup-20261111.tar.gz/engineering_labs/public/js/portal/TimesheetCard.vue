<template>
	<WidgetCard title="Timesheet Entry" icon="clock">
		<p class="tw-m-0 tw-mb-[10px] tw-text-[9px] tw-text-[#333]">You haven't submitted your timesheet for this week.</p>
		<span class="tw-flex tw-cursor-default tw-items-center tw-justify-center tw-gap-[6px] tw-rounded-[3px] tw-bg-[#00a0e3] tw-px-0 tw-py-[6px] tw-text-[11px] tw-text-white">
			Enter Timesheet
			<span class="timesheet__button-icon" v-html="icons.plus"></span>
		</span>
	</WidgetCard>
</template>

<script setup>
import WidgetCard from "./WidgetCard.vue";
import { icons } from "./icons";
</script>


<style scoped>
.timesheet__button-icon,
.timesheet__button-icon :deep(svg) {
	display: block;
	width: 10px;
	height: 10px;
}
</style>
