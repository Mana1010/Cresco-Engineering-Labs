<template>
	<div class="tw-flex tw-flex-col tw-gap-[22px]">
		<div class="tw-grid tw-grid-cols-4 tw-gap-[10px] max-1100:tw-mb-[14px]">
			<MetricCard v-for="stat in stats" :key="stat.label" v-bind="stat" />
		</div>

		<section>
			<h2 class="tw-m-0 tw-mb-[10px] tw-text-[11px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Awaiting Approval</h2>
			<AwaitingApprovalList
				:items="awaiting"
				@show="openDetails($event, { fromAwaiting: true })"
				@approve="runAction(approveCalculation, $event)"
				@return-to-draft="runAction(returnToDraft, $event)"
			/>
		</section>

		<section>
			<div class="tw-mb-[12px] tw-flex tw-flex-wrap tw-items-center tw-justify-between tw-gap-[10px]">
				<h2 class="tw-m-0 tw-text-[11px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">All Calculations</h2>
				<div class="tw-flex tw-flex-wrap tw-items-center tw-gap-[8px]">
					<CalculationFilters v-model:type="filters.type" v-model:status="filters.status" />
					<ViewToggle v-model="viewMode" />
					<!-- Static for now: adding a tool isn't implemented yet -->
					<button
						type="button"
						class="tw-inline-flex tw-h-[34px] tw-cursor-pointer tw-items-center tw-gap-[6px] tw-rounded-[6px] tw-border-0 tw-bg-portal-primary tw-px-[14px] tw-py-0 tw-text-[12px] tw-font-bold tw-text-[#fff] [font-family:inherit] [font-style:inherit] [font-variant:inherit] [font-stretch:inherit] [line-height:inherit] hover:[filter:brightness(0.93)]"
					>
						<span
							class="registry__add-icon"
							aria-hidden="true"
							v-html="icons.plus"
						></span>
						Add
					</button>
				</div>
			</div>
			<CalculationSearch v-model="searchText" class="tw-mb-[14px]" />

			<div v-if="viewMode === 'grid'" class="tw-grid tw-grid-cols-3 tw-gap-4 max-1100:tw-grid-cols-2 max-640:tw-grid-cols-1">
				<CalculationCard v-for="calc in items" :key="calc.id" :calc="calc" @open="openDetails" />
			</div>
			<CalculationTable v-else :calculations="items" @open="openDetails" />

			<RegistryEmptyState
				v-if="done && !items.length"
				:search="filters.search"
				:has-filters="hasFilters"
				@clear-search="searchText = ''"
				@reset-filters="resetFilters"
			/>
			<div v-if="loadError" class="tw-mt-4 tw-flex tw-items-center tw-justify-center tw-gap-[10px] tw-text-[12px] tw-text-portal-red" role="alert">
				Couldn't load calculations.
				<button
					type="button"
					class="tw-cursor-pointer tw-rounded-[6px] tw-border tw-border-solid tw-border-[#d5dbe1] tw-bg-[#fff] tw-px-[12px] tw-py-[5px] tw-text-[12px] tw-font-semibold tw-text-portal-text [font-family:inherit] [font-style:inherit] [font-variant:inherit] [font-stretch:inherit] [line-height:inherit]"
					@click="retryLoad"
				>Retry</button>
			</div>
			<div v-if="loading" class="tw-mt-[18px] tw-flex tw-items-center tw-justify-center tw-gap-[10px] tw-text-[12px] tw-text-portal-muted" role="status">
				<span
					class="registry__spinner"
					aria-hidden="true"
				></span>
				{{ items.length ? "Loading more calculations…" : "Loading calculations…" }}
			</div>
			<p v-else-if="done && items.length" class="tw-m-0 tw-mt-4 tw-text-center tw-text-[12px] tw-text-portal-muted">You've reached the end of the list.</p>
			<div ref="sentinel" class="tw-h-[1px]" aria-hidden="true"></div>
		</section>

		<CalculationDetailsModal
			v-if="selected"
			:calc="selected"
			:show-status-actions="!openedFromAwaiting"
			@updated="applyUpdate"
			@close="selected = null"
			@view-calculation="previewOpen = true"
		/>
		<CalculationPreviewModal v-if="selected && previewOpen" :calc="selected" @close="previewOpen = false" />
	</div>
</template>

<script setup>
import { computed, onBeforeUnmount, onMounted, reactive, ref, watch } from "vue";
import { showError } from "../api";
import MetricCard from "../engineering_labs/MetricCard.vue";
import { icons } from "../icons";
import AwaitingApprovalList from "../tools_registry/AwaitingApprovalList.vue";
import CalculationCard from "../tools_registry/CalculationCard.vue";
import CalculationDetailsModal from "../tools_registry/CalculationDetailsModal.vue";
import CalculationFilters from "../tools_registry/CalculationFilters.vue";
import CalculationPreviewModal from "../tools_registry/CalculationPreviewModal.vue";
import CalculationSearch from "../tools_registry/CalculationSearch.vue";
import CalculationTable from "../tools_registry/CalculationTable.vue";
import RegistryEmptyState from "../tools_registry/RegistryEmptyState.vue";
import ViewToggle from "../tools_registry/ViewToggle.vue";
import {
	approveCalculation,
	fetchAwaitingCalculations,
	fetchCalculationStats,
	fetchCalculations,
	returnToDraft,
} from "../tools_registry/registryData";

const PAGE_SIZE = 15;
const SEARCH_DEBOUNCE_MS = 300;

const VIEW_MODE_KEY = "engineering_labs.tools_registry.view_mode";

const viewMode = ref(readViewMode());
const filters = reactive({ type: "", status: "Approved", search: "" });
const searchText = ref("");

const hasFilters = computed(() => Boolean(filters.type || filters.status));

function resetFilters() {
	filters.type = "";
	filters.status = "";
}

const items = ref([]);
const loading = ref(false);
const done = ref(false);
const loadError = ref(false);
const sentinel = ref(null);
// Bumped on every filter change so responses from a superseded query are discarded.
let queryId = 0;

// Status counts and the awaiting list come from the server and are refreshed after every action.
const statusCounts = ref({});
const awaiting = ref([]);

const countByStatus = (status) => statusCounts.value[status] ?? 0;

async function refreshSummary() {
	try {
		[statusCounts.value, awaiting.value] = await Promise.all([fetchCalculationStats(), fetchAwaitingCalculations()]);
	} catch (error) {
		showError(error);
	}
}

const stats = computed(() => [
	{ label: "Approved & Live", value: String(countByStatus("Approved")), tone: "green" },
	{
		label: "Awaiting Approval",
		value: String(countByStatus("Awaiting approval")),
		caption: "needs your review",
		tone: "orange",
	},
	{ label: "Draft", value: String(countByStatus("Draft")) },
	{ label: "Deprecated", value: String(countByStatus("Deprecated")), tone: "red" },
]);

async function loadMore() {
	if (loading.value || done.value || loadError.value) return;

	loading.value = true;
	loadError.value = false;
	const currentQuery = queryId;
	let result;
	try {
		result = await fetchCalculations({ offset: items.value.length, limit: PAGE_SIZE, ...filters });
	} catch (error) {
		if (currentQuery !== queryId) return;
		console.error("Failed to load calculations", error);
		loadError.value = true;
		loading.value = false;
		return;
	}
	if (currentQuery !== queryId) return;

	items.value.push(...result.items);
	done.value = items.value.length >= result.total;
	loading.value = false;

	// Re-observe so a sentinel that is still on screen (short page) triggers the next batch.
	if (observer && sentinel.value) {
		observer.unobserve(sentinel.value);
		observer.observe(sentinel.value);
	}
}

function retryLoad() {
	loadError.value = false;
	loadMore();
}

function resetAndLoad() {
	queryId += 1;
	items.value = [];
	done.value = false;
	loading.value = false;
	loadError.value = false;
	loadMore();
}

// Calculation shown in the details modal; the preview modal opens on top of it.
const selected = ref(null);
const previewOpen = ref(false);
const openedFromAwaiting = ref(false);

function openDetails(calc, { fromAwaiting = false } = {}) {
	selected.value = calc;
	previewOpen.value = false;
	openedFromAwaiting.value = fromAwaiting;
}

// Puts an updated calculation (returned by an action) everywhere it's shown, then refreshes counts.
function applyUpdate(updated) {
	const index = items.value.findIndex((calc) => calc.id === updated.id);
	if (index !== -1) items.value[index] = { ...items.value[index], ...updated };
	if (selected.value?.id === updated.id) selected.value = { ...selected.value, ...updated };
	refreshSummary();
}

async function runAction(action, calc) {
	try {
		applyUpdate(await action(calc.id));
	} catch (error) {
		showError(error);
	}
}

let observer = null;

onMounted(() => {
	observer = new IntersectionObserver(
		(entries) => {
			if (entries.some((entry) => entry.isIntersecting)) loadMore();
		},
		{ rootMargin: "300px 0px" }
	);
	observer.observe(sentinel.value);
	loadMore();
	refreshSummary();
});

onBeforeUnmount(() => {
	observer?.disconnect();
	clearTimeout(searchTimer);
});

watch(filters, resetAndLoad);

// Debounce typing so the list refetches once the user pauses, not on every keystroke.
let searchTimer = null;
watch(searchText, (text) => {
	clearTimeout(searchTimer);
	searchTimer = setTimeout(() => (filters.search = text), text ? SEARCH_DEBOUNCE_MS : 0);
});

// Remember the grid/table choice per browser; storage can be unavailable (private mode), so fail quietly.
function readViewMode() {
	try {
		return localStorage.getItem(VIEW_MODE_KEY) === "table" ? "table" : "grid";
	} catch {
		return "grid";
	}
}

watch(viewMode, (mode) => {
	try {
		localStorage.setItem(VIEW_MODE_KEY, mode);
	} catch {
		// Ignore: the choice just won't persist.
	}
});
</script>

<style scoped>
/* Kept as CSS: icon sizing reaches into v-html svg; spinner uses its own keyframes. */
.registry__add-icon,
.registry__add-icon :deep(svg) {
	display: block;
	width: 11px;
	height: 11px;
}

.registry__spinner {
	width: 18px;
	height: 18px;
	border: 2px solid #d5e9f3;
	border-top-color: var(--portal-primary);
	border-radius: 50%;
	animation: registry-spin 0.7s linear infinite;
}

@keyframes registry-spin {
	to {
		transform: rotate(360deg);
	}
}
</style>
