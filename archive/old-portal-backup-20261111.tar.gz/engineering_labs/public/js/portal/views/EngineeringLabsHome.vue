<template>
	<p v-if="loading" class="tw-mx-0 tw-my-6 tw-text-center tw-text-[13px] tw-text-portal-muted">
		Loading Engineering Labs…
	</p>
	<p
		v-else-if="error"
		class="tw-mx-0 tw-my-6 tw-text-center tw-text-[13px] tw-text-portal-muted"
	>
		Couldn't load Engineering Labs. {{ error }}
	</p>
	<div v-else class="tw-flex tw-flex-col tw-gap-[18px]">
		<section>
			<h2
				class="tw-m-0 tw-mb-[10px] tw-text-[11px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate"
			>
				Lead indicators
			</h2>
			<div
				class="tw-grid tw-grid-cols-[repeat(4,minmax(0,1fr))] tw-gap-[10px] max-1100:tw-grid-cols-[repeat(2,minmax(0,1fr))] max-480:tw-grid-cols-[minmax(0,1fr)]"
			>
				<MetricCard v-for="metric in leadIndicators" :key="metric.label" v-bind="metric" />
			</div>
		</section>

		<section>
			<h2
				class="tw-m-0 tw-mb-[10px] tw-text-[11px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate"
			>
				Volume (secondary)
			</h2>
			<div
				class="tw-grid tw-grid-cols-[repeat(4,minmax(0,1fr))] tw-gap-[10px] max-1100:tw-grid-cols-[repeat(2,minmax(0,1fr))] max-480:tw-grid-cols-[minmax(0,1fr)]"
			>
				<MetricCard
					v-for="metric in volumeIndicators"
					:key="metric.label"
					v-bind="metric"
				/>
			</div>
		</section>

		<div
			class="tw-grid tw-grid-cols-[repeat(2,minmax(0,1fr))] tw-items-start tw-gap-[14px] max-900:tw-grid-cols-[minmax(0,1fr)]"
		>
			<ReviewOutcomesPanel v-bind="reviewOutcomes" />
			<div class="tw-flex tw-flex-col tw-gap-[14px]">
				<ConsistencyFlagsPanel v-bind="consistencyFlags" />
				<TimelinessPanel :rows="timeliness" />
			</div>
		</div>

		<div
			class="tw-grid tw-grid-cols-[repeat(2,minmax(0,1fr))] tw-items-start tw-gap-[14px] max-900:tw-grid-cols-[minmax(0,1fr)]"
		>
			<ToolPopularityPanel :tools="toolPopularity" />
			<div class="tw-flex tw-flex-col tw-gap-[14px]">
				<ApiQuotaPanel :quotas="apiQuotas" />
				<ApiHealthPanel :apis="apiHealth" />
			</div>
		</div>
	</div>
</template>

<script setup>
import ApiHealthPanel from "../engineering_labs/ApiHealthPanel.vue";
import ApiQuotaPanel from "../engineering_labs/ApiQuotaPanel.vue";
import ConsistencyFlagsPanel from "../engineering_labs/ConsistencyFlagsPanel.vue";
import MetricCard from "../engineering_labs/MetricCard.vue";
import ReviewOutcomesPanel from "../engineering_labs/ReviewOutcomesPanel.vue";
import TimelinessPanel from "../engineering_labs/TimelinessPanel.vue";
import ToolPopularityPanel from "../engineering_labs/ToolPopularityPanel.vue";
import { computed, onMounted, ref } from "vue";
import { call } from "../api";
import { longDate } from "../dates";

// Labs Metric / Consistency Flag / External API doctypes, shaped for the home page panels.
const loading = ref(true);
const error = ref("");
const home = ref({ metrics: {}, flags: [], apis: [] });

onMounted(async () => {
	try {
		home.value = await call("get_labs_home");
	} catch (err) {
		error.value = err.message;
	} finally {
		loading.value = false;
	}
});

const section = (name) => home.value.metrics[name] || [];
const toMetricCard = (m) => ({
	label: m.label,
	value: m.display_value || "",
	caption: m.caption || "",
	tone: m.tone || "",
});
const toCount = (m) => ({ label: m.label, count: m.count_value || 0, tone: m.tone || undefined });
const summaryCount = (label) =>
	section("Review Summary").find((m) => m.label === label)?.count_value || 0;

const leadIndicators = computed(() => section("Lead Indicator").map(toMetricCard));
const volumeIndicators = computed(() => section("Volume").map(toMetricCard));
const timeliness = computed(() =>
	section("Timeliness").map((m) => ({ label: m.label, value: m.display_value })),
);
const toolPopularity = computed(() => section("Tool Popularity").map(toCount));

const reviewOutcomes = computed(() => ({
	passed: summaryCount("Passed"),
	returned: summaryCount("Returned"),
	reviewed: summaryCount("Reviewed"),
	returnReasons: section("Return Reason").map(toCount),
	correctedFields: section("Corrected Field").map(toCount),
	note: "Aggregated per tool. Per-engineer views are restricted to the Engineering Manager (AI Policy — verification standard).",
}));

const consistencyFlags = computed(() => ({
	flags: home.value.flags.map((f) => ({
		reference: f.project_name ? `${f.reference} · ${f.project_name}` : f.reference,
		message: f.message,
	})),
	note: "A flag is raised when a calculation consumes a value with no governed upstream source, or one that differs from it (e.g. CheckWind wind data, geotechnical parameters, standard edition).",
}));

// Quota bar turns orange from 60% used and red from 90%.
const quotaTone = (used, limit) =>
	used / limit >= 0.9 ? "red" : used / limit >= 0.6 ? "orange" : "green";

const apiQuotas = computed(() =>
	home.value.apis
		.filter((api) => api.quota_limit)
		.map((api) => ({
			label: api.api_name,
			used: api.quota_used || 0,
			limit: api.quota_limit,
			unit: api.quota_unit || "",
			renews: api.quota_renews_on ? `Renews ${longDate(api.quota_renews_on)}` : "",
			tone: quotaTone(api.quota_used || 0, api.quota_limit),
		})),
);

const apiHealth = computed(() =>
	home.value.apis.map((api) => ({
		label: api.api_name,
		latency: `${api.latency_ms ?? "—"} ms`,
		errors: api.errors_24h || 0,
		status: api.health_status || "ok",
	})),
);
</script>
