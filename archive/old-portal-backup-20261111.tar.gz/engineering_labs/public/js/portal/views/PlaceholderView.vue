<template>
	<section class="portal-card tw-p-7">
		<h2 class="tw-m-0 tw-mb-[6px] tw-text-[18px] tw-font-bold tw-text-[#222]">{{ title }}</h2>
		<p class="tw-m-0 tw-text-[13px] tw-text-[#777]">This page hasn't been built yet.</p>
	</section>
</template>

<script setup>
defineProps({
	title: { type: String, required: true },
});
</script>

