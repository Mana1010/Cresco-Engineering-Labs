<template>
	<div class="tw-flex tw-flex-col tw-gap-[14px]">
		<div class="tw-flex tw-justify-end">
			<button type="button" class="catalogue__add tw-inline-flex tw-h-[34px] tw-cursor-pointer tw-items-center tw-gap-[6px] tw-rounded-[6px] tw-border-0 tw-bg-portal-primary tw-px-[14px] tw-py-0 tw-text-white hover:[filter:brightness(0.93)]" @click="addOpen = true">
				<span class="catalogue__add-icon" aria-hidden="true" v-html="icons.plus"></span>
				Add
			</button>
		</div>

		<PlaceholderView title="Calculation Catalogue" />

		<AddCalculationModal v-if="addOpen" @close="addOpen = false" />
	</div>
</template>

<script setup>
import { ref } from "vue";
import AddCalculationModal from "../calculation_catalogue/AddCalculationModal.vue";
import { icons } from "../icons";
import PlaceholderView from "./PlaceholderView.vue";

const addOpen = ref(false);
</script>

<style scoped>
.catalogue__add {
	font: inherit;
	font-size: 12px;
	font-weight: 700;
}

.catalogue__add-icon,
.catalogue__add-icon :deep(svg) {
	display: block;
	width: 11px;
	height: 11px;
}
</style>
