<template>
	<p v-if="loading" class="tw-mx-0 tw-my-6 tw-text-center tw-text-[13px] tw-text-portal-muted">Loading dashboard…</p>
	<p v-else-if="error" class="tw-mx-0 tw-my-6 tw-text-center tw-text-[13px] tw-text-portal-muted">Couldn't load the dashboard. {{ error }}</p>
	<div v-else class="tw-flex tw-flex-col tw-gap-[18px]">
		<div class="tw-grid tw-grid-cols-4 tw-gap-[10px] max-1100:tw-grid-cols-2 max-640:tw-grid-cols-1">
			<StatCard v-for="stat in stats" :key="stat.label" v-bind="stat" />
		</div>
		<div class="tw-grid tw-grid-cols-[minmax(0,1fr)_292px] tw-items-start tw-gap-[22px] max-900:tw-grid-cols-1">
			<NewsfeedHero v-if="newsfeed" v-bind="newsfeed" />
			<div class="tw-flex tw-flex-col tw-gap-[10px]">
				<TimesheetCard />
				<BirthdaysCard :people="birthdays" />
				<EventsCard :events="events" />
			</div>
		</div>
	</div>
</template>

<script setup>
import BirthdaysCard from "../BirthdaysCard.vue";
import EventsCard from "../EventsCard.vue";
import NewsfeedHero from "../NewsfeedHero.vue";
import StatCard from "../StatCard.vue";
import TimesheetCard from "../TimesheetCard.vue";
import { onMounted, ref } from "vue";
import { call } from "../api";
import { eventParts, monthDay } from "../dates";

// Portal Stat / News Post / Team Member / Event doctypes, shaped for the dashboard components.
const loading = ref(true);
const error = ref("");
const stats = ref([]);
const newsfeed = ref(null);
const birthdays = ref([]);
const events = ref([]);

onMounted(async () => {
	try {
		const data = await call("get_portal_dashboard");
		stats.value = data.stats.map((s) => ({
			value: s.display_value,
			label: s.label,
			sublabel: s.sublabel,
			icon: s.icon,
			tone: s.tone,
		}));
		newsfeed.value = data.newsfeed && {
			imageSrc: data.newsfeed.image || null,
			title: data.newsfeed.title,
			body: data.newsfeed.body,
		};
		birthdays.value = data.birthdays.map((b) => ({
			name: b.full_name,
			role: b.job_title,
			date: monthDay(b.next_birthday),
			image: b.image || null,
		}));
		events.value = data.events.map((e) => ({ title: e.title, location: e.location, ...eventParts(e.starts_on) }));
	} catch (err) {
		error.value = err.message;
	} finally {
		loading.value = false;
	}
});
</script>

