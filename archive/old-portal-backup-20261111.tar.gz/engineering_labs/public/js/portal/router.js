import { createRouter, createWebHistory } from "vue-router";
import CalculationCatalogueView from "./views/CalculationCatalogueView.vue";
import DashboardView from "./views/DashboardView.vue";
import EngineeringLabsHome from "./views/EngineeringLabsHome.vue";
import ToolsRegistryView from "./views/ToolsRegistryView.vue";

export const routes = [
	{ path: "/portal", name: "dashboard", component: DashboardView },
	{ path: "/engineering-labs", redirect: "/engineering-labs/home" },
	{ path: "/engineering-labs/home", name: "el-home", component: EngineeringLabsHome },
	{
		path: "/engineering-labs/calculation-catalogue",
		name: "el-calculation-catalogue",
		component: CalculationCatalogueView,
	},
	{ path: "/engineering-labs/tools-registry", name: "el-tools-registry", component: ToolsRegistryView },
	{ path: "/engineering-labs/:pathMatch(.*)*", redirect: "/engineering-labs/home" },
];

export const router = createRouter({
	history: createWebHistory(),
	routes,
	scrollBehavior: () => ({ top: 0 }),
});
