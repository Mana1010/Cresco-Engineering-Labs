<template>
	<img v-if="src" :src="src" :alt="name" class="tw-inline-flex tw-shrink-0 tw-items-center tw-justify-center tw-rounded-[50%] tw-object-cover tw-shadow-[0_0_0_2px_#fff,0_1px_4px_rgba(0,0,0,0.15)]" :style="sizeStyle" />
	<span v-else class="tw-inline-flex tw-shrink-0 tw-items-center tw-justify-center tw-rounded-[50%] tw-object-cover tw-shadow-[0_0_0_2px_#fff,0_1px_4px_rgba(0,0,0,0.15)] tw-bg-[#d8e9f3] tw-font-bold tw-text-[#1d5e85]" :style="sizeStyle">{{ initials }}</span>
</template>

<script setup>
import { computed } from "vue";

const props = defineProps({
	name: { type: String, default: "" },
	src: { type: String, default: null },
	size: { type: Number, default: 36 },
});

const initials = computed(() =>
	props.name
		.split(/\s+/)
		.filter(Boolean)
		.slice(0, 2)
		.map((part) => part[0].toUpperCase())
		.join("")
);

const sizeStyle = computed(() => ({
	width: `${props.size}px`,
	height: `${props.size}px`,
	fontSize: `${Math.round(props.size * 0.38)}px`,
}));
</script>

