<template>
	<WidgetCard title="Cresco Birthdays" icon="cake" action-label="View all" footer-label="See all birthdays">
		<p v-if="!people.length" class="tw-mx-0 tw-mb-[2px] tw-mt-[6px] tw-text-[10px] tw-text-[#999]">No birthdays to show.</p>
		<ul v-else class="tw-m-0 tw-mt-1 tw-list-none tw-p-0">
			<li v-for="person in people" :key="person.name" class="tw-flex tw-items-center tw-gap-[10px] tw-px-0 tw-py-1">
				<Avatar :name="person.name" :src="person.image" :size="28" />
				<div>
					<div class="tw-text-[11px] tw-font-bold tw-text-[#222]">{{ person.name }}</div>
					<div class="tw-text-[8px] tw-text-[#999]">{{ person.role }}</div>
				</div>
				<span class="tw-ml-auto tw-text-[9px] tw-text-[#aaa]">{{ person.date }}</span>
			</li>
		</ul>
	</WidgetCard>
</template>

<script setup>
import Avatar from "./Avatar.vue";
import WidgetCard from "./WidgetCard.vue";

defineProps({
	people: { type: Array, required: true },
});
</script>

