<template>
	<Teleport to="body">
		<div
			class="portal-modal tw-fixed tw-inset-0 tw-flex tw-items-center tw-justify-center tw-bg-[rgba(20,24,30,0.45)] tw-px-4 tw-py-6 tw-font-portal"
			:style="{ zIndex: 1100 + depth * 10 }"
			@mousedown.self="close"
		>
			<div
				ref="dialog"
				class="portal-modal__dialog tw-flex tw-max-h-[calc(100vh-48px)] tw-w-full tw-flex-col tw-rounded-[10px] tw-bg-[#fff] tw-shadow-[0_20px_50px_rgba(0,0,0,0.25)] [outline:none]"
				:class="SIZE_CLASSES[size] || ''"
				role="dialog"
				aria-modal="true"
				:aria-labelledby="titleId"
				tabindex="-1"
			>
				<header
					class="tw-flex tw-items-start tw-justify-between tw-gap-3 tw-border-0 tw-border-b tw-border-solid tw-border-b-[#e8ecf0] tw-px-5 tw-py-4"
				>
					<div class="tw-min-w-0 tw-flex-1">
						<slot name="header" :title-id="titleId">
							<h2 :id="titleId" class="tw-m-0 tw-text-[15px] tw-font-bold tw-text-portal-text">{{ title }}</h2>
						</slot>
					</div>
					<button
						type="button"
						class="tw-h-[28px] tw-w-[28px] tw-shrink-0 tw-cursor-pointer tw-rounded-[50%] tw-border-0 tw-bg-transparent tw-p-[7px] tw-text-portal-muted hover:tw-bg-[#eef2f6] hover:tw-text-portal-text [&_svg]:tw-block [&_svg]:tw-h-full [&_svg]:tw-w-full"
						aria-label="Close"
						@click="close"
					>
						<span v-html="icons.close"></span>
					</button>
				</header>
				<div class="tw-overflow-y-auto tw-px-5 tw-py-[18px]">
					<slot />
				</div>
				<footer
					v-if="$slots.footer"
					class="tw-flex tw-flex-wrap tw-items-center tw-gap-[10px] tw-border-0 tw-border-t tw-border-solid tw-border-t-[#e8ecf0] tw-px-5 tw-py-[14px]"
				>
					<slot name="footer" />
				</footer>
			</div>
		</div>
	</Teleport>
</template>

<script>
// Shared across instances: the open-modal stack (only the top one reacts to Escape) and an id counter.
const openStack = [];
let nextId = 0;

// The portal reserves the scrollbar's space (scrollbar-gutter: stable). A fixed backdrop can't cover
// that reserved strip, so while a modal is open swap the gutter for equal body padding instead:
// the layout doesn't shift and the backdrop covers the full viewport.
function lockPageScroll() {
	const html = document.documentElement;
	const gutterWidth = window.innerWidth - html.clientWidth;
	html.style.scrollbarGutter = "auto";
	html.style.overflow = "hidden";
	document.body.style.paddingRight = `${gutterWidth}px`;
}

function unlockPageScroll() {
	const html = document.documentElement;
	html.style.scrollbarGutter = "";
	html.style.overflow = "";
	document.body.style.paddingRight = "";
}
</script>

<script setup>
import { nextTick, onBeforeUnmount, onMounted, ref } from "vue";
import { icons } from "./icons";

defineProps({
	// Used for the default heading; a #header slot can replace it (it receives titleId for aria).
	title: { type: String, default: "" },
	size: { type: String, default: "md" },
});

const emit = defineEmits(["close"]);

// Full class strings (not built dynamically) so Tailwind can find them when scanning the source.
const SIZE_CLASSES = {
	md: "tw-max-w-[540px]",
	lg: "tw-max-w-[860px]",
	xl: "tw-max-w-[1080px]",
};

const dialog = ref(null);
const titleId = `portal-modal-title-${++nextId}`;
const token = Symbol("modal");
const depth = openStack.length;
let previouslyFocused = null;

function close() {
	emit("close");
}

function onKeydown(event) {
	if (event.key === "Escape" && openStack[openStack.length - 1] === token) {
		event.stopPropagation();
		close();
	}
}

onMounted(() => {
	previouslyFocused = document.activeElement;
	if (!openStack.length) lockPageScroll();
	openStack.push(token);
	document.addEventListener("keydown", onKeydown);
	nextTick(() => dialog.value?.focus({ preventScroll: true }));
});

onBeforeUnmount(() => {
	openStack.splice(openStack.indexOf(token), 1);
	if (!openStack.length) unlockPageScroll();
	document.removeEventListener("keydown", onKeydown);
	previouslyFocused?.focus?.({ preventScroll: true });
});
</script>

<style scoped>
/* Kept as plain CSS (hybrid Tailwind conversion): the keyframe animations. */
.portal-modal {
	animation: portal-modal-fade 0.15s ease-out;
}

.portal-modal__dialog {
	animation: portal-modal-pop 0.15s ease-out;
}

@keyframes portal-modal-fade {
	from {
		opacity: 0;
	}
}

@keyframes portal-modal-pop {
	from {
		opacity: 0;
		transform: translateY(8px) scale(0.98);
	}
}
</style>
