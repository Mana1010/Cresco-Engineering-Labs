<template>
	<span
		class="tw-inline-block tw-whitespace-nowrap tw-rounded-full tw-px-[9px] tw-py-[2px] tw-text-[10px] tw-font-medium"
		:class="STATUS_CLASSES[status] || ''"
	>
		{{ status }}
	</span>
</template>

<script setup>
defineProps({
	status: { type: String, required: true },
});

// Full class strings (not built dynamically) so Tailwind can find them when scanning the source.
const STATUS_CLASSES = {
	Approved: "tw-bg-[#e3f4e9] tw-text-[#217a43]",
	"Awaiting approval": "tw-bg-[#fdeee2] tw-text-[#b8580f]",
	Draft: "tw-bg-[#eceff3] tw-text-[#4f5b6d]",
	Deprecated: "tw-bg-[#fbe5e6] tw-text-[#b3262e]",
};
</script>
