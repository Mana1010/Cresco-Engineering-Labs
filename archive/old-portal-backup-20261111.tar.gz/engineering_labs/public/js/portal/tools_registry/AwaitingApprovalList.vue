<template>
	<div class="tw-flex tw-max-h-[250px] tw-flex-col tw-gap-[8px] tw-overflow-y-auto tw-pb-[4px] tw-pl-[2px] tw-pr-[6px] tw-pt-[2px]">
		<p v-if="!items.length" class="portal-card tw-m-0 tw-p-[18px] tw-text-[12px] tw-text-portal-muted">Nothing is waiting for approval.</p>
		<article
			v-for="calc in items"
			:key="calc.id"
			class="portal-card tw-flex tw-shrink-0 tw-items-center tw-justify-between tw-gap-[14px] tw-border-0 tw-border-l-[3px] tw-border-solid tw-border-l-portal-orange tw-px-[14px] tw-py-[10px] max-760:tw-flex-col max-760:tw-items-start"
		>
			<div>
				<div class="tw-mb-[2px] tw-flex tw-flex-wrap tw-items-center tw-gap-x-[8px] tw-gap-y-[4px]">
					<h3 class="tw-m-0 tw-text-[13px] tw-font-bold tw-text-portal-text">{{ calc.name }}</h3>
					<CalcBadges :type="calc.type" :autonomous="calc.autonomous" />
				</div>
				<p class="tw-m-0 tw-text-[11px] tw-text-portal-muted">
					{{ calc.source }} · <span class="tw-font-mono">{{ calc.version }}</span> · submitted
					{{ calc.submittedOn }} by {{ calc.submittedBy }}
				</p>
			</div>
			<div class="tw-flex tw-shrink-0 tw-flex-wrap tw-gap-[6px]">
				<button type="button" :class="[BTN, BTN_OUTLINE]" @click="$emit('show', calc)">
					Show Calculation
				</button>
				<button type="button" :class="[BTN, BTN_APPROVE]" @click="$emit('approve', calc)">
					Approve
				</button>
				<button type="button" :class="[BTN, BTN_OUTLINE]" @click="$emit('return-to-draft', calc)">
					Return to draft
				</button>
			</div>
		</article>
	</div>
</template>

<script setup>
import CalcBadges from "./CalcBadges.vue";

defineProps({
	items: { type: Array, required: true },
});

defineEmits(["show", "approve", "return-to-draft"]);

// Shared button classes plus one full class string per variant (kept literal so Tailwind finds them).
const BTN =
	"tw-cursor-pointer tw-rounded-[5px] tw-border tw-border-solid tw-px-[10px] tw-py-[5px] tw-text-[11px] tw-font-semibold [font-family:inherit] [font-style:inherit] [font-variant:inherit] [font-stretch:inherit] [line-height:inherit] disabled:tw-cursor-default disabled:tw-opacity-[0.55]";
const BTN_OUTLINE = "tw-border-[#d5dbe1] tw-bg-[#fff] tw-text-portal-text enabled:hover:tw-bg-[#f4f6f9]";
const BTN_APPROVE = "tw-border-transparent tw-bg-portal-green tw-text-[#fff] hover:[filter:brightness(0.92)]";
</script>
