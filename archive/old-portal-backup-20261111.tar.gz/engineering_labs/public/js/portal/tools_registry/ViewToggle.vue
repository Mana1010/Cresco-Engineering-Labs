<template>
	<div class="tw-inline-flex tw-rounded-[6px] tw-border tw-border-solid tw-border-[#d5dbe1] tw-bg-[#fff] tw-p-[3px]" role="group" aria-label="Layout">
		<button
			v-for="option in options"
			:key="option.value"
			type="button"
			class="tw-flex tw-h-[26px] tw-w-[30px] tw-cursor-pointer tw-items-center tw-justify-center tw-rounded-[4px] tw-border-0 tw-p-0"
			:class="
				modelValue === option.value
					? 'tw-bg-portal-primary tw-text-[#fff]'
					: 'tw-bg-transparent tw-text-portal-slate hover:tw-bg-[#f0f3f6]'
			"
			:aria-pressed="modelValue === option.value"
			:aria-label="option.label"
			:title="option.label"
			@click="$emit('update:modelValue', option.value)"
		>
			<span class="view-toggle__icon" v-html="icons[option.icon]"></span>
		</button>
	</div>
</template>

<script setup>
import { icons } from "../icons";

defineProps({
	modelValue: { type: String, required: true },
});

defineEmits(["update:modelValue"]);

const options = [
	{ value: "grid", label: "Grid view", icon: "grid" },
	{ value: "table", label: "Table view", icon: "table" },
];
</script>

<style scoped>
/* Kept as CSS: sizing of the v-html svg. */
.view-toggle__icon,
.view-toggle__icon :deep(svg) {
	display: block;
	width: 15px;
	height: 15px;
}
</style>
