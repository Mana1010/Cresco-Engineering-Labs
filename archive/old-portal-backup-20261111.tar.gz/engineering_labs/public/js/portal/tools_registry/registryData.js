// Tools Registry data, backed by the Labs Calculation doctype (engineering_labs.api).
// API rows are converted to the camelCase shape the registry components use.
import { call } from "../api";

export const STATUSES = ["Approved", "Awaiting approval", "Draft", "Deprecated"];
export const TYPES = ["API", "Python", "Excel"];

// Provider name for API tools, e.g. "Revolutio Hazard API" from "Revolutio Hazard API · AS 4055".
export const engineName = (calc) => (calc.source || "").split(" · ")[0];

export function toCalc(row) {
	return {
		id: row.name,
		name: row.calculation_name,
		source: row.engine_source || "",
		type: row.calculation_type,
		autonomous: Boolean(row.autonomous),
		category: row.category,
		version: row.version,
		status: row.status,
		author: row.author,
		submittedBy: row.submitted_by,
		submittedOn: row.submitted_on,
		approvedBy: row.approved_by,
		approvedOn: row.approved_on,
		description: row.description,
		attribution: row.attribution,
		// Only present on full records (get_calculation and the actions).
		notes: row.notes?.map((note) => ({ author: note.note_by, text: note.note, date: note.note_date })),
		preview: row.preview,
	};
}

export async function fetchCalculations({ offset = 0, limit = 15, type = "", status = "", search = "" } = {}) {
	const result = await call("get_calculations", { offset, limit, calculation_type: type, status, search });
	return { items: result.items.map(toCalc), total: result.total };
}

export const fetchCalculationStats = () => call("get_calculation_stats");

export const fetchAwaitingCalculations = async () => (await call("get_awaiting_calculations")).map(toCalc);

export const fetchCalculation = async (id) => toCalc(await call("get_calculation", { name: id }));

export const fetchCalculationByName = async (calculationName) =>
	toCalc(await call("get_calculation", { calculation_name: calculationName }));

const action = (method) => async (id, args = {}) => toCalc(await call(method, { name: id, ...args }, { post: true }));

export const approveCalculation = action("approve_calculation");
export const reapproveCalculation = action("reapprove_calculation");
export const returnToDraft = action("return_calculation_to_draft");
export const deprecateCalculation = action("deprecate_calculation");
export const addNote = (id, note) => action("add_calculation_note")(id, { note });

export const runCalculationPreview = (id, inputs) =>
	call("run_calculation_preview", { name: id, inputs: JSON.stringify(inputs) }, { post: true });

export function runLabel(calc) {
	if (calc.type === "API") return `Run via ${engineName(calc)}`;
	if (calc.type === "Excel") return "Run workbook";
	return "Run calculation";
}
