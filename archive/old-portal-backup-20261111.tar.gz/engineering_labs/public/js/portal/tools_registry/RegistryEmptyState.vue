<template>
	<div class="portal-card tw-flex tw-flex-col tw-items-center tw-px-[24px] tw-py-[40px] tw-text-center" role="status">
		<span
			class="empty-state__icon tw-box-border tw-flex tw-h-[52px] tw-w-[52px] tw-items-center tw-justify-center tw-rounded-[50%] tw-bg-[#e2f2fa] tw-p-[14px] tw-text-portal-primary"
			aria-hidden="true"
			v-html="icons.search"
		></span>
		<h3 class="tw-m-0 tw-mb-[6px] tw-mt-[14px] tw-text-[15px] tw-font-bold tw-text-portal-text">No calculations found</h3>
		<p
			class="tw-m-0 tw-max-w-[420px] tw-text-[12px] tw-leading-[1.5] tw-text-portal-muted [word-break:break-word]"
		>
			<template v-if="search">
				Nothing matches “<strong class="tw-text-portal-text">{{ search }}</strong>”<template v-if="hasFilters"> with the current filters</template>.
				Try a different name, standard, category or version.
			</template>
			<template v-else>There are no calculations with the current filters.</template>
		</p>
		<div class="tw-mt-4 tw-flex tw-flex-wrap tw-justify-center tw-gap-[8px]">
			<button
				v-if="search"
				type="button"
				:class="[BTN, 'tw-border-0 tw-bg-portal-primary tw-text-[#fff]']"
				@click="$emit('clear-search')"
			>
				Clear search
			</button>
			<button
				v-if="hasFilters"
				type="button"
				:class="[BTN, 'tw-border tw-border-solid tw-border-[#d5dbe1] tw-bg-[#fff] tw-text-portal-text']"
				@click="$emit('reset-filters')"
			>
				Reset filters
			</button>
		</div>
	</div>
</template>

<script setup>
import { icons } from "../icons";

defineProps({
	search: { type: String, default: "" },
	hasFilters: { type: Boolean, default: false },
});

defineEmits(["clear-search", "reset-filters"]);

const BTN =
	"tw-cursor-pointer tw-rounded-[6px] tw-px-[14px] tw-py-[7px] tw-text-[12px] tw-font-semibold [font-family:inherit] [font-style:inherit] [font-variant:inherit] [font-stretch:inherit] [line-height:inherit] hover:[filter:brightness(0.93)]";
</script>

<style scoped>
/* Kept as CSS: sizing of the v-html svg. */
.empty-state__icon :deep(svg) {
	display: block;
	width: 100%;
	height: 100%;
}
</style>
