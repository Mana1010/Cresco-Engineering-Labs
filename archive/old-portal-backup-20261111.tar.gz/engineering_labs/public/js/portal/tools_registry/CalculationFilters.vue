<template>
	<div class="tw-flex tw-flex-wrap tw-gap-[8px]">
		<select
			:class="SELECT"
			aria-label="Filter by type"
			:value="type"
			@change="$emit('update:type', $event.target.value)"
		>
			<option value="">All types</option>
			<option v-for="option in TYPES" :key="option" :value="option">{{ option }}</option>
		</select>
		<select
			:class="SELECT"
			aria-label="Filter by status"
			:value="status"
			@change="$emit('update:status', $event.target.value)"
		>
			<option value="">All statuses</option>
			<option v-for="option in STATUSES" :key="option" :value="option">{{ option }}</option>
		</select>
	</div>
</template>

<script setup>
import { STATUSES, TYPES } from "./registryData";

const SELECT =
	"tw-h-[34px] tw-min-w-[130px] tw-cursor-pointer tw-rounded-[6px] tw-border tw-border-solid tw-border-[#d5dbe1] tw-bg-[#fff] tw-px-[10px] tw-text-[12px] tw-text-portal-text [font-family:inherit] [font-style:inherit] [font-variant:inherit] [font-stretch:inherit] [line-height:inherit] [font-weight:inherit]";

defineProps({
	type: { type: String, default: "" },
	status: { type: String, default: "" },
});

defineEmits(["update:type", "update:status"]);
</script>
