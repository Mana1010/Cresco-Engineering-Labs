<template>
	<div class="portal-card tw-overflow-x-auto">
		<table class="calc-table tw-w-full tw-min-w-[760px] tw-border-collapse tw-text-[12px]">
			<thead>
				<tr>
					<th>Calculation</th>
					<th>Type</th>
					<th>Category</th>
					<th>Ver</th>
					<th>Status</th>
					<th>Approved by</th>
					<th aria-hidden="true"></th>
				</tr>
			</thead>
			<tbody>
				<tr
					v-for="calc in calculations"
					:key="calc.id"
					tabindex="0"
					:aria-label="`View details for ${calc.name}`"
					@click="$emit('open', calc)"
					@keydown.enter.prevent="$emit('open', calc)"
					@keydown.space.prevent="$emit('open', calc)"
				>
					<td>
						<div class="calc-table__name tw-flex tw-flex-wrap tw-items-center tw-gap-[6px] tw-font-bold">
							{{ calc.name }}
							<span
								v-if="calc.autonomous"
								class="tw-inline-flex tw-items-center tw-gap-[3px] tw-rounded-full tw-bg-[#fdeee2] tw-px-[7px] tw-py-[1px] tw-text-[10px] tw-font-medium tw-text-[#b8580f]"
							>
								<span class="calc-table__icon" v-html="icons.bolt"></span>
								autonomous
							</span>
						</div>
						<div class="tw-mt-[2px] tw-text-[10px] tw-text-portal-muted">{{ calc.source }}</div>
					</td>
					<td><CalcBadges :type="calc.type" show-icons /></td>
					<td class="calc-table__muted">{{ calc.category }}</td>
					<td class="calc-table__mono">{{ calc.version }}</td>
					<td><StatusPill :status="calc.status" /></td>
					<td class="calc-table__muted">
						<template v-if="calc.approvedBy">{{ calc.approvedBy }} · {{ calc.approvedOn }}</template>
						<template v-else>—</template>
					</td>
					<td class="calc-table__chevron">
						<span class="calc-table__icon" v-html="icons.chevronRight"></span>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</template>

<script setup>
import { icons } from "../icons";
import CalcBadges from "./CalcBadges.vue";
import StatusPill from "./StatusPill.vue";

defineProps({
	calculations: { type: Array, required: true },
});

defineEmits(["open"]);
</script>

<style scoped>
/* Kept as CSS: th/td/row rules, row hover restyling child cells, and v-html svg sizing. */
.calc-table th {
	padding: 10px 14px;
	background: #f4f6f9;
	font-size: 9px;
	font-weight: 700;
	letter-spacing: 0.5px;
	text-align: left;
	text-transform: uppercase;
	color: var(--portal-slate);
}

.calc-table td {
	padding: 10px 14px;
	border-top: 1px solid #edf0f3;
	vertical-align: middle;
	color: var(--portal-text);
}

.calc-table tbody tr {
	cursor: pointer;
	transition: background 0.12s ease;
}

.calc-table tbody tr:focus-visible {
	outline: 2px solid var(--portal-primary);
	outline-offset: -2px;
}

.calc-table tbody tr:hover {
	background: #eef7fc;
}

.calc-table tbody tr:hover .calc-table__name {
	color: #0b7fb3;
}

.calc-table tbody tr:hover .calc-table__chevron {
	color: var(--portal-primary);
}

.calc-table__muted {
	color: var(--portal-muted);
}

.calc-table__mono {
	font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
	color: var(--portal-muted);
}

.calc-table__chevron {
	width: 14px;
	color: var(--portal-muted);
}

.calc-table__icon,
.calc-table__icon :deep(svg) {
	display: block;
	width: 11px;
	height: 11px;
}
</style>
