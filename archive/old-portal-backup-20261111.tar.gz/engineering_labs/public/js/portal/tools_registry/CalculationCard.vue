<template>
	<article
		class="portal-card calc-card tw-flex tw-cursor-pointer tw-flex-col tw-px-[18px] tw-pb-[14px] tw-pt-[18px] [transition:box-shadow_0.15s_ease,transform_0.15s_ease]"
		role="button"
		tabindex="0"
		:aria-label="`View details for ${calc.name}`"
		@click="$emit('open', calc)"
		@keydown.enter.prevent="$emit('open', calc)"
		@keydown.space.prevent="$emit('open', calc)"
	>
		<CalcBadges :type="calc.type" :autonomous="calc.autonomous" />
		<h3
			class="calc-card__title tw-m-0 tw-mb-[2px] tw-mt-[12px] tw-text-[15px] tw-font-bold tw-leading-[1.3] tw-text-portal-text [transition:color_0.15s_ease]"
		>{{ calc.name }}</h3>
		<p
			class="tw-m-0 tw-border-0 tw-border-b tw-border-solid tw-border-b-[#e8ecf0] tw-pb-[12px] tw-text-[11px] tw-text-portal-muted"
		>{{ calc.source }}</p>

		<dl
			class="tw-m-0 tw-mt-[14px] tw-grid tw-grid-cols-2 tw-gap-x-[14px] tw-gap-y-[12px] [&_dd]:tw-m-0 [&_dd]:tw-text-[12px] [&_dd]:tw-text-portal-text [&_dt]:tw-mb-[2px] [&_dt]:tw-text-[9px] [&_dt]:tw-font-medium [&_dt]:tw-uppercase [&_dt]:tw-tracking-[0.5px] [&_dt]:tw-text-portal-slate"
		>
			<div>
				<dt>Category</dt>
				<dd>{{ calc.category }}</dd>
			</div>
			<div>
				<dt>Version</dt>
				<dd class="tw-font-mono">{{ calc.version }}</dd>
			</div>
			<div>
				<dt>Status</dt>
				<dd><StatusPill :status="calc.status" /></dd>
			</div>
			<div>
				<dt>Approved by</dt>
				<dd>
					<template v-if="calc.approvedBy">
						{{ calc.approvedBy }}
						<span class="tw-block tw-text-[10px] tw-text-portal-muted">{{ calc.approvedOn }}</span>
					</template>
					<span v-else class="tw-text-portal-muted">—</span>
				</dd>
			</div>
		</dl>

		<span
			class="calc-card__open tw-mt-auto tw-box-border tw-flex tw-h-[26px] tw-w-[26px] tw-items-center tw-justify-center tw-self-end tw-rounded-[50%] tw-bg-[#eef2f6] tw-p-[7px] tw-text-portal-slate [transition:background_0.15s_ease,color_0.15s_ease]"
			aria-hidden="true"
			v-html="icons.arrowRight"
		></span>
	</article>
</template>

<script setup>
import { icons } from "../icons";
import CalcBadges from "./CalcBadges.vue";
import StatusPill from "./StatusPill.vue";

defineProps({
	calc: { type: Object, required: true },
});

defineEmits(["open"]);
</script>

<style scoped>
/* Kept as CSS: hover/focus-visible states that restyle child elements, and v-html svg sizing. */
.calc-card:focus-visible {
	outline: none;
	box-shadow: 0 0 0 2px var(--portal-primary);
}

.calc-card:hover {
	box-shadow:
		0 0 0 1px var(--portal-primary),
		0 6px 16px rgba(0, 0, 0, 0.1);
	transform: translateY(-2px);
}

.calc-card:hover .calc-card__title {
	color: #0b7fb3;
}

.calc-card:hover .calc-card__open {
	background: var(--portal-primary);
	color: #fff;
}

.calc-card__open :deep(svg) {
	display: block;
	width: 100%;
	height: 100%;
}
</style>
