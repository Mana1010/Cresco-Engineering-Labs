<template>
	<BaseModal :title="detail.name" @close="$emit('close')">
		<div class="tw-flex tw-flex-wrap tw-items-center tw-gap-[6px]">
			<CalcBadges :type="detail.type" show-icons />
			<StatusPill :status="detail.status" />
			<span class="tw-rounded-full tw-bg-[#eceff3] tw-px-2 tw-py-[2px] tw-font-mono tw-text-[10px] tw-text-[#4f5b6d]">{{ detail.version }}</span>
			<span
				v-if="detail.autonomous"
				class="tw-inline-flex tw-items-center tw-gap-1 tw-rounded-full tw-bg-[#fdeee2] tw-px-2 tw-py-[2px] tw-text-[10px] tw-font-medium tw-text-[#b8580f]"
			>
				<span
					class="details-icon"
					v-html="icons.bolt"
				></span>
				autonomous-capable
			</span>
		</div>

		<p class="tw-m-0 tw-mb-[14px] tw-mt-[12px] tw-text-[13px] tw-leading-[1.5] tw-text-portal-text">{{ detail.description }}</p>

		<button
			type="button"
			class="details-view-btn tw-inline-flex tw-items-center tw-gap-[6px] tw-rounded-[6px] tw-border-0 tw-bg-portal-primary tw-px-[12px] tw-py-[7px] tw-text-[#fff]"
			@click="$emit('view-calculation')"
		>
			<span
				class="details-icon"
				v-html="icons.eye"
			></span>
			View calculation
		</button>

		<dl
			class="tw-m-0 tw-mt-[18px] tw-grid tw-grid-cols-[repeat(2,minmax(0,1fr))] tw-gap-x-[20px] tw-gap-y-[14px] max-480:tw-grid-cols-[minmax(0,1fr)]"
		>
			<div>
				<dt class="tw-mb-[3px] tw-text-[9px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Engine</dt>
				<dd class="tw-m-0 tw-text-[12px] tw-font-bold tw-text-portal-text">{{ detail.source }}</dd>
			</div>
			<div>
				<dt class="tw-mb-[3px] tw-text-[9px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Category</dt>
				<dd class="tw-m-0 tw-text-[12px] tw-font-bold tw-text-portal-text">{{ detail.category }}</dd>
			</div>
			<div>
				<dt class="tw-mb-[3px] tw-text-[9px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Author</dt>
				<dd class="tw-m-0 tw-text-[12px] tw-font-bold tw-text-portal-text">{{ detail.author }}</dd>
			</div>
			<div>
				<dt class="tw-mb-[3px] tw-text-[9px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Approved by</dt>
				<dd class="tw-m-0 tw-text-[12px] tw-font-bold tw-text-portal-text">
					<template v-if="detail.approvedBy">{{ detail.approvedBy }} · {{ detail.approvedOn }}</template>
					<template v-else>—</template>
				</dd>
			</div>
		</dl>

		<p v-if="detail.attribution" class="tw-m-0 tw-mt-4 tw-rounded-[6px] tw-bg-[#f2f5f8] tw-px-[12px] tw-py-[10px] tw-text-[11px] tw-text-portal-slate">Attribution required: “{{ detail.attribution }}”.</p>

		<section class="tw-mt-[18px] tw-border-0 tw-border-t tw-border-solid tw-border-t-[#e8ecf0] tw-pt-[14px]">
			<h3 class="tw-m-0 tw-mb-[10px] tw-text-[10px] tw-font-bold tw-uppercase tw-tracking-[0.5px] tw-text-portal-slate">Notes ({{ notes.length }})</h3>
			<p v-if="!detail.notes" class="tw-m-0 tw-mb-[10px] tw-text-[12px] tw-text-portal-muted">Loading notes…</p>
			<p v-else-if="!notes.length" class="tw-m-0 tw-mb-[10px] tw-text-[12px] tw-text-portal-muted">No notes yet.</p>
			<div v-for="(note, index) in notes" :key="index" class="tw-mb-2 tw-rounded-[6px] tw-bg-[#f2f5f8] tw-px-[12px] tw-py-[9px]">
				<div class="tw-text-[10px] tw-text-portal-muted">
					<strong class="tw-text-portal-text">{{ note.author }}</strong> · {{ note.date }}
				</div>
				<div class="tw-mt-[3px] tw-whitespace-pre-wrap tw-text-[12px] tw-text-portal-text [word-break:break-word]">{{ note.text }}</div>
			</div>
			<form class="tw-mt-[10px] tw-flex tw-gap-2" @submit.prevent="submitNote">
				<input
					v-model="noteText"
					class="details-note-input tw-h-[34px] tw-min-w-0 tw-flex-1 tw-rounded-[6px] tw-border tw-border-solid tw-border-[#d5dbe1] tw-px-[10px] tw-py-0 tw-text-portal-text"
					type="text"
					placeholder="Add a note (usage guidance, limits, caveats)…"
					aria-label="Add a note"
				/>
				<button
					type="submit"
					class="details-note-btn tw-shrink-0 tw-rounded-[6px] tw-border tw-border-solid tw-border-[#cfe7f4] tw-bg-[#eef7fc] tw-px-[12px] tw-py-0 tw-text-[#0b7fb3]"
					:disabled="busy || !noteText.trim()"
				>
					Add note
				</button>
			</form>
		</section>

		<template v-if="showStatusActions && (detail.status === 'Approved' || detail.status === 'Deprecated')" #footer>
			<button
				v-if="detail.status === 'Approved'"
				type="button"
				class="details-action tw-rounded-[6px] tw-border-0 tw-px-4 tw-py-2 tw-text-[#fff] tw-bg-portal-orange"
				:disabled="busy"
				@click="perform(deprecateCalculation)"
			>
				Deprecate
			</button>
			<button
				v-else
				type="button"
				class="details-action tw-rounded-[6px] tw-border-0 tw-px-4 tw-py-2 tw-text-[#fff] tw-bg-portal-green"
				:disabled="busy"
				@click="perform(reapproveCalculation)"
			>
				Re-approve
			</button>
			<span class="tw-text-[11px] tw-text-portal-muted">Acting as {{ userName }}</span>
		</template>
	</BaseModal>
</template>

<script setup>
import { computed, inject, onMounted, ref } from "vue";
import { showError } from "../api";
import BaseModal from "../BaseModal.vue";
import { icons } from "../icons";
import CalcBadges from "./CalcBadges.vue";
import StatusPill from "./StatusPill.vue";
import { addNote, deprecateCalculation, fetchCalculation, reapproveCalculation } from "./registryData";

const props = defineProps({
	calc: { type: Object, required: true },
	// Off when opened from Awaiting Approval, where Deprecate / Re-approve don't apply.
	showStatusActions: { type: Boolean, default: true },
});

const emit = defineEmits(["close", "view-calculation", "updated"]);

const user = inject("portalUser", {});
const userName = computed(() => user.full_name || user.first_name || "");

// Starts as the list row; replaced by the full record (with notes) once it loads.
const detail = ref(props.calc);
const notes = computed(() => detail.value.notes || []);
const noteText = ref("");
const busy = ref(false);

onMounted(async () => {
	try {
		detail.value = await fetchCalculation(props.calc.id);
	} catch (error) {
		showError(error);
	}
});

// Runs an API action, shows the returned record and tells the page so lists and counts update.
async function perform(action, ...args) {
	busy.value = true;
	try {
		detail.value = await action(detail.value.id, ...args);
		emit("updated", detail.value);
		return true;
	} catch (error) {
		showError(error);
		return false;
	} finally {
		busy.value = false;
	}
}

async function submitNote() {
	const text = noteText.value.trim();
	if (text && (await perform(addNote, text))) noteText.value = "";
}
</script>

<style scoped>
/* Kept as plain CSS: font shorthand, hover/focus/disabled states and :deep(svg) icons. */
.details-icon,
.details-icon :deep(svg) {
	display: block;
	width: 11px;
	height: 11px;
}

.details-view-btn {
	font: inherit;
	font-size: 12px;
	font-weight: 600;
	cursor: pointer;
}

.details-view-btn:hover {
	filter: brightness(0.93);
}

.details-view-btn .details-icon,
.details-view-btn .details-icon :deep(svg) {
	width: 13px;
	height: 13px;
}

.details-note-input {
	font: inherit;
	font-size: 12px;
}

.details-note-input:focus {
	border-color: var(--portal-primary);
	outline: none;
	box-shadow: 0 0 0 3px rgba(0, 160, 227, 0.15);
}

.details-note-btn {
	font: inherit;
	font-size: 12px;
	font-weight: 600;
	cursor: pointer;
}

.details-note-btn:disabled {
	cursor: default;
	opacity: 0.55;
}

.details-action {
	font: inherit;
	font-size: 12px;
	font-weight: 700;
	cursor: pointer;
}

.details-action:disabled {
	cursor: default;
	opacity: 0.6;
}

.details-action:hover:not(:disabled) {
	filter: brightness(0.93);
}
</style>
