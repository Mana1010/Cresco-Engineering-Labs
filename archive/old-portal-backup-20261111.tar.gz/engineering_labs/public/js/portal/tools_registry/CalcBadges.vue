<template>
	<span class="tw-inline-flex tw-flex-wrap tw-gap-[6px]">
		<span class="tw-inline-flex tw-items-center tw-gap-1 tw-whitespace-nowrap tw-rounded-full tw-px-2 tw-py-[2px] tw-text-[10px] tw-font-medium tw-bg-[#e2f2fa] tw-text-[#1676a3]">
			<span v-if="showIcons" class="calc-badge-icon" v-html="icons[typeIcons[type]]"></span>
			{{ type }}
		</span>
		<span v-if="autonomous" class="tw-inline-flex tw-items-center tw-gap-1 tw-whitespace-nowrap tw-rounded-full tw-px-2 tw-py-[2px] tw-text-[10px] tw-font-medium tw-bg-[#fdeee2] tw-text-[#b8580f]">
			<span v-if="showIcons" class="calc-badge-icon" v-html="icons.bolt"></span>
			Autonomous
		</span>
	</span>
</template>

<script setup>
import { icons } from "../icons";

defineProps({
	type: { type: String, required: true },
	autonomous: { type: Boolean, default: false },
	showIcons: { type: Boolean, default: false },
});

const typeIcons = { API: "swap", Python: "terminal", Excel: "sheet" };
</script>

<style scoped>
/* Kept as plain CSS: :deep(svg) sizing for the v-html icon. */
.calc-badge-icon,
.calc-badge-icon :deep(svg) {
	display: block;
	width: 10px;
	height: 10px;
}
</style>
