<template>
	<label class="tw-relative tw-m-0 tw-flex tw-items-center">
		<span
			class="calc-search__icon tw-pointer-events-none tw-absolute tw-left-[12px] tw-h-[15px] tw-w-[15px] tw-text-portal-muted"
			aria-hidden="true"
			v-html="icons.search"
		></span>
		<input
			class="calc-search__input tw-box-border tw-h-[38px] tw-w-full tw-appearance-none tw-rounded-[6px] tw-border tw-border-solid tw-border-[#d5dbe1] tw-bg-[#fff] tw-px-[36px] tw-py-0 tw-text-[13px] tw-text-portal-text [font-family:inherit] [font-style:inherit] [font-variant:inherit] [font-stretch:inherit] [line-height:inherit] [font-weight:inherit] focus:tw-border-portal-primary focus:[box-shadow:0_0_0_3px_rgba(0,160,227,0.15)] focus:[outline:none]"
			type="search"
			placeholder="Search calculations by name, standard, category or version"
			aria-label="Search calculations"
			:value="modelValue"
			@input="$emit('update:modelValue', $event.target.value)"
		/>
		<button
			v-if="modelValue"
			type="button"
			class="calc-search__clear tw-absolute tw-right-[8px] tw-h-[22px] tw-w-[22px] tw-cursor-pointer tw-rounded-[50%] tw-border-0 tw-bg-transparent tw-p-[6px] tw-text-portal-muted hover:tw-bg-[#eef2f6] hover:tw-text-portal-text"
			aria-label="Clear search"
			@click="$emit('update:modelValue', '')"
		>
			<span v-html="icons.close"></span>
		</button>
	</label>
</template>

<script setup>
import { icons } from "../icons";

defineProps({
	modelValue: { type: String, default: "" },
});

defineEmits(["update:modelValue"]);
</script>

<style scoped>
/* Kept as CSS: sizing of the v-html svgs and hiding WebKit's native clear button. */
.calc-search__icon :deep(svg),
.calc-search__clear :deep(svg) {
	display: block;
	width: 100%;
	height: 100%;
}

.calc-search__input::-webkit-search-cancel-button {
	display: none;
}
</style>
