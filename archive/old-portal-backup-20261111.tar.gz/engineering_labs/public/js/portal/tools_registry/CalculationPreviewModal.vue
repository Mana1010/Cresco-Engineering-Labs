<template>
	<BaseModal :title="`Preview — ${calc.name}`" size="lg" @close="$emit('close')">
		<p
			class="tw-m-0 tw-mb-4 tw-rounded-[6px] tw-border tw-border-solid tw-border-[#cfe7f4] tw-bg-[#eef7fc] tw-px-[12px] tw-py-[10px] tw-text-[11px] tw-text-[#0b6f9c]"
		>
			Catalogue preview — not attached to a project. Runs here are for inspection only and are not recorded
			against a job.
		</p>
		<CalculationRunner :calc="calc" />
	</BaseModal>
</template>

<script setup>
import BaseModal from "../BaseModal.vue";
import CalculationRunner from "./CalculationRunner.vue";

defineProps({
	calc: { type: Object, required: true },
});

defineEmits(["close"]);
</script>
