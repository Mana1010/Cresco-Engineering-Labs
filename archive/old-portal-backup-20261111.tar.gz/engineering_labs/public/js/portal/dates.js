// Small date formatters for API values ("2026-11-19" / "2026-11-19 09:00:00"), avoiding timezone shifts.
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"];

function parts(value) {
	const [datePart, timePart = ""] = String(value).split(" ");
	const [year, month, day] = datePart.split("-").map(Number);
	const [hour = 0, minute = 0] = timePart.split(":").map(Number);
	return { year, month, day, hour, minute };
}

// "Sept 4"
export const monthDay = (value) => {
	const { month, day } = parts(value);
	return `${MONTHS[month - 1]} ${day}`;
};

// "1 Aug 2026"
export const longDate = (value) => {
	const { year, month, day } = parts(value);
	return `${day} ${MONTHS[month - 1]} ${year}`;
};

// { day: 19, month: "Nov", time: "9:00am" }
export const eventParts = (value) => {
	const { month, day, hour, minute } = parts(value);
	const suffix = hour < 12 ? "am" : "pm";
	const hour12 = hour % 12 || 12;
	return { day, month: MONTHS[month - 1], time: `${hour12}:${String(minute).padStart(2, "0")}${suffix}` };
};
