from urllib.parse import quote

import frappe

no_cache = 1


def get_context(context):
	if frappe.session.user == "Guest":
		frappe.local.flags.redirect_location = f"/login?redirect-to={quote(frappe.request.path)}"
		raise frappe.Redirect

	user = frappe.get_cached_doc("User", frappe.session.user)

	context.no_cache = 1
	context.title = "Cresco Hub"
	context.portal_user = {
		"first_name": user.first_name or user.full_name or user.name,
		"full_name": user.full_name or user.name,
		"user_image": user.user_image,
	}
