/**
 * Tailwind config for the Cresco portal (/portal, /engineering-labs/*).
 *
 * - `tw-` prefix: the portal page also loads Frappe's website CSS (Bootstrap), which has classes with
 *   the same names as Tailwind utilities (.border, .rounded, .shadow, ...). The prefix avoids clashes.
 * - preflight off: Tailwind's CSS reset would change how Frappe's base page renders.
 * - Build: `yarn legacy:build-css`, or `yarn legacy:watch-css` to watch while editing. (The old embedded
 *   portal is no longer routed; the portal is now served from frontend/.)
 */
module.exports = {
	prefix: "tw-",
	content: ["./engineering_labs/public/js/portal/**/*.{vue,js}", "./engineering_labs/www/portal.html"],
	corePlugins: { preflight: false },
	theme: {
		extend: {
			colors: {
				// Backed by the CSS variables in public/css/tailwind.css
				portal: {
					primary: "var(--portal-primary)",
					green: "var(--portal-green)",
					orange: "var(--portal-orange)",
					red: "var(--portal-red)",
					slate: "var(--portal-slate)",
					text: "var(--portal-text)",
					muted: "var(--portal-muted)",
					track: "var(--portal-track)",
				},
			},
			fontFamily: {
				portal: ['"Helvetica Neue"', "Helvetica", "Arial", "sans-serif"],
				mono: ["ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
			},
			// The portal's layouts break at these widths (desktop-first, so max-width queries).
			// Order matters: narrower screens come later so they override wider ones.
			screens: {
				"max-1100": { max: "1100px" },
				"max-900": { max: "900px" },
				"max-768": { max: "768px" },
				"max-760": { max: "760px" },
				"max-640": { max: "640px" },
				"max-480": { max: "480px" },
			},
			keyframes: {
				"flyout-in": { from: { opacity: "0", transform: "translateX(-4px)" } },
				"modal-fade": { from: { opacity: "0" } },
				"modal-pop": { from: { opacity: "0", transform: "translateY(8px) scale(0.98)" } },
				spin: { to: { transform: "rotate(360deg)" } },
			},
			animation: {
				"flyout-in": "flyout-in 0.12s ease-out",
				"modal-fade": "modal-fade 0.15s ease-out",
				"modal-pop": "modal-pop 0.15s ease-out",
				"spin-fast": "spin 0.7s linear infinite",
			},
		},
	},
	plugins: [],
};
